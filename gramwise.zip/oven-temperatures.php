<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/templates/faq-block.php';

$table = oven_temperature_table();

$page_title = 'Oven Temperature Converter: Fahrenheit, Celsius & Gas Mark | ' . get_setting('site_name');
$page_description = 'Convert oven temperatures between Fahrenheit, Celsius and UK Gas Mark with this quick reference table for baking and roasting.';
$breadcrumbs = [['label' => 'Oven Temperature Converter']];

$faqs = [
    ['question' => 'Is 180°C the same as 350°F?', 'answer' => '180°C converts to exactly 356°F, but recipes commonly round this to 350°F, which is close enough for most baking. If precision matters for delicate bakes, use the exact converted value.'],
    ['question' => 'What is a Gas Mark 4 in Fahrenheit?', 'answer' => 'Gas Mark 4 corresponds to approximately 350°F (180°C), a very common "moderate" oven setting used in many British recipes.'],
    ['question' => 'Does fan/convection oven temperature need adjusting?', 'answer' => 'Yes. As a general rule, reduce the temperature by about 20°C (25°F) when a recipe was written for a conventional oven but you are using a fan/convection oven, or check your oven manual for its specific guidance.'],
];

require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <h1>Oven Temperature Converter</h1>
  <p>Use this table to quickly convert between Fahrenheit, Celsius and UK Gas Mark for baking and roasting. For any other value, use our <a href="/converters.php?from=celsius&to=fahrenheit#calculator">Celsius to Fahrenheit calculator</a>.</p>

  <table class="conv-table">
    <thead><tr><th>Fahrenheit</th><th>Celsius</th><th>Gas Mark</th><th>Description</th></tr></thead>
    <tbody>
      <?php foreach ($table as $row): [$f, $c, $gas, $desc] = $row; ?>
        <tr><td><?= h((string)$f) ?>°F</td><td><?= h((string)$c) ?>°C</td><td>Gas <?= h($gas) ?></td><td><?= h($desc) ?></td></tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <div class="formula-box">Formula: °F = (°C × 9/5) + 32 &nbsp;|&nbsp; °C = (°F − 32) × 5/9</div>

  <?php render_faq_block($faqs); ?>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
