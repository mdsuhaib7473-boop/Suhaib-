<?php
/** Dynamic robots.txt served via .htaccess rewrite from /robots.txt */
require_once __DIR__ . '/includes/functions.php';
header('Content-Type: text/plain; charset=utf-8');
echo "User-agent: *\n";
echo "Disallow: /admin/\n";
echo "Disallow: /api/\n";
echo "Disallow: /includes/\n";
echo "Disallow: /config/\n";
echo "Disallow: /search.php\n";
echo "Allow: /\n\n";
echo "Sitemap: " . canonical_url('/sitemap.xml') . "\n";
