<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/templates/calculator.php';
require_once __DIR__ . '/templates/faq-block.php';
require_once __DIR__ . '/templates/related-links.php';

$slug = trim((string) ($_GET['slug'] ?? ''));
$stmt = db()->prepare("SELECT i.*, c.name AS category_name FROM ingredients i LEFT JOIN categories c ON c.id = i.category_id WHERE i.slug = :s AND i.status = 'published'");
$stmt->execute(['s' => $slug]);
$ingredient = $stmt->fetch();

if (!$ingredient) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$units = db()->query('SELECT * FROM units WHERE is_active = 1 ORDER BY sort_order')->fetchAll();
$allIngredients = db()->query("SELECT id, name, slug FROM ingredients WHERE status = 'published' ORDER BY name")->fetchAll();

$gram = get_unit_by_slug('grams');
$cup = get_unit_by_slug('cups');
$tbsp = get_unit_by_slug('tablespoons');
$tsp = get_unit_by_slug('teaspoons');
$density = (float) $ingredient['density_g_per_ml'];

$commonConversions = [
    ['label' => '1 cup ' . $ingredient['name'] . ' in grams', 'value' => round(convert_amount(1, $cup, $gram, $density), 1) . ' g'],
    ['label' => '100 grams ' . $ingredient['name'] . ' in cups', 'value' => format_number(convert_amount(100, $gram, $cup, $density), 3) . ' cup'],
    ['label' => '1 tablespoon ' . $ingredient['name'] . ' in grams', 'value' => round(convert_amount(1, $tbsp, $gram, $density), 1) . ' g'],
    ['label' => '1 teaspoon ' . $ingredient['name'] . ' in grams', 'value' => round(convert_amount(1, $tsp, $gram, $density), 1) . ' g'],
];

// Popular conversion page links: check if generated pages exist, else fall back to calculator preset
$popLinksRaw = [
    ['amount' => 100, 'conv' => 'grams-to-cups', 'label' => '100 grams ' . $ingredient['name'] . ' to cups'],
    ['amount' => 200, 'conv' => 'grams-to-cups', 'label' => '200 grams ' . $ingredient['name'] . ' to cups'],
    ['amount' => 1, 'conv' => 'cups-to-grams', 'label' => '1 cup ' . $ingredient['name'] . ' to grams'],
];
$popularLinks = [];
foreach ($popLinksRaw as $p) {
    $pageStmt = db()->prepare(
        "SELECT cp.full_url FROM conversion_pages cp
         JOIN conversion_types ct ON ct.id = cp.conversion_type_id
         WHERE ct.slug = :conv AND cp.ingredient_id = :ing AND cp.amount = :amt AND cp.status = 'published'"
    );
    $pageStmt->execute(['conv' => $p['conv'], 'ing' => $ingredient['id'], 'amt' => $p['amount']]);
    $found = $pageStmt->fetchColumn();
    $url = $found ?: ('/converters.php?from=' . ($p['conv'] === 'grams-to-cups' ? 'grams&to=cups' : 'cups&to=grams') . '#calculator');
    $popularLinks[] = ['label' => $p['label'], 'url' => $url];
}

$relatedIngredients = array_slice(array_filter($allIngredients, fn($i) => $i['id'] != $ingredient['id']), 0, 4);

$faqStmt = db()->prepare("SELECT question, answer FROM faqs WHERE entity_type = 'ingredient' AND entity_id = :id AND status = 'published' ORDER BY sort_order");
$faqStmt->execute(['id' => $ingredient['id']]);
$faqs = $faqStmt->fetchAll();
if (!$faqs) {
    // Sensible generic default so every ingredient page has FAQ content without manual entry.
    $faqs = [
        ['question' => 'Why does ' . $ingredient['name'] . ' convert differently than other ingredients?', 'answer' => $ingredient['name'] . ' has its own density (roughly ' . $density . ' g per ml), so the same cup or tablespoon measurement weighs a different amount than lighter or denser ingredients like flour or sugar.'],
        ['question' => 'Is it better to weigh ' . $ingredient['name'] . ' or measure it by volume?', 'answer' => 'Weighing with a kitchen scale is generally more accurate and consistent, especially for baking, since volume measurements can vary depending on how the ingredient is packed or leveled.'],
    ];
}

$page_title = $ingredient['seo_title'] ?: ($ingredient['name'] . ' Measurement & Conversion Guide | ' . get_setting('site_name'));
$page_description = $ingredient['meta_description'] ?: $ingredient['short_description'];
$breadcrumbs = [['label' => 'Ingredients', 'url' => '/ingredients.php'], ['label' => $ingredient['name']]];

require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <span class="pill"><?= h($ingredient['category_name'] ?? 'Ingredient') ?></span>
  <h1><?= h($ingredient['name']) ?> Measurement Guide</h1>
  <p><?= h($ingredient['short_description']) ?></p>

  <?php render_calculator($units, $allIngredients, ['amount' => 100, 'from' => 'grams', 'to' => 'cups', 'ingredient' => $ingredient['slug']]); ?>

  <h2>About <?= h($ingredient['name']) ?></h2>
  <p><?= nl2br(h($ingredient['detailed_description'])) ?></p>

  <h2>Common Conversions</h2>
  <table class="conv-table">
    <thead><tr><th>Conversion</th><th>Result</th></tr></thead>
    <tbody>
      <?php foreach ($commonConversions as $row): ?>
        <tr><td><?= h($row['label']) ?></td><td><?= h($row['value']) ?></td></tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <?php render_related_links('Popular Conversions', $popularLinks); ?>

  <h2>Measurement Tips</h2>
  <ul>
    <li>For the most accurate results, weigh <?= h($ingredient['name']) ?> on a kitchen scale rather than using cup measurements.</li>
    <li>If measuring by volume, spoon the ingredient into the measuring cup and level it off with a straight edge rather than scooping directly from the container.</li>
    <li>Ingredient density can vary slightly by brand, moisture content and how tightly it is packed, so treat volume conversions as a close estimate rather than an exact figure.</li>
  </ul>

  <?php render_related_links('Related Ingredients', array_map(fn($i) => ['label' => $i['name'], 'url' => '/ingredients/' . $i['slug'] . '/'], $relatedIngredients)); ?>

  <?php render_faq_block($faqs); ?>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
