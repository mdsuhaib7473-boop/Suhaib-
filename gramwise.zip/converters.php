<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/templates/calculator.php';

$units = db()->query('SELECT * FROM units WHERE is_active = 1 ORDER BY sort_order')->fetchAll();
$ingredients = db()->query("SELECT id, name, slug FROM ingredients WHERE status = 'published' ORDER BY name")->fetchAll();
$types = db()->query(
    'SELECT ct.*, fu.slug AS from_slug, tu.slug AS to_slug
     FROM conversion_types ct
     JOIN units fu ON fu.id = ct.from_unit_id
     JOIN units tu ON tu.id = ct.to_unit_id
     WHERE ct.is_active = 1 ORDER BY ct.category, ct.sort_order'
)->fetchAll();

$byCategory = [];
foreach ($types as $t) {
    $byCategory[$t['category']][] = $t;
}

$presetFrom = preg_replace('/[^a-z0-9\-]/', '', strtolower($_GET['from'] ?? 'grams'));
$presetTo   = preg_replace('/[^a-z0-9\-]/', '', strtolower($_GET['to'] ?? 'cups'));

$page_title = 'All Cooking Measurement Converters | ' . get_setting('site_name');
$page_description = 'Every kitchen unit converter in one place: grams, cups, tablespoons, teaspoons, ounces, pounds, milliliters and oven temperatures.';
$breadcrumbs = [['label' => 'All Converters']];

require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <h1>All Converters</h1>
  <p>Pick any conversion below and the calculator updates instantly — adjust the amount, swap units, or choose an ingredient for weight-to-volume conversions.</p>

  <div id="calculator" class="calc-anchor">
    <?php render_calculator($units, $ingredients, ['amount' => 100, 'from' => $presetFrom, 'to' => $presetTo, 'ingredient' => 'flour']); ?>
  </div>

  <?php foreach ($byCategory as $category => $convs): ?>
    <div class="section-head" style="margin-top:36px;">
      <h2 id="<?= h(slugify($category)) ?>"><?= h($category) ?></h2>
    </div>
    <div class="card-grid">
      <?php foreach ($convs as $c): ?>
        <a class="card" id="<?= h($c['slug']) ?>" href="/converters.php?from=<?= h($c['from_slug'] ?? '') ?>&to=<?= h($c['to_slug'] ?? '') ?>#calculator"
           onclick="return false;" data-conv-from="<?= h($c['slug']) ?>">
          <h3><?= h($c['name']) ?></h3>
          <p><?= $c['requires_ingredient'] ? 'Requires an ingredient (weight ⇄ volume).' : 'Direct unit conversion.' ?></p>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>
</section>

<script>
// Wire up quick-select cards to update the calculator instantly without navigation.
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-conv-from]').forEach(function (card) {
    card.addEventListener('click', function (e) {
      e.preventDefault();
      var url = new URL(card.href, window.location.origin);
      var from = url.searchParams.get('from');
      var to = url.searchParams.get('to');
      var fromEl = document.getElementById('calc-from');
      var toEl = document.getElementById('calc-to');
      if (from && fromEl.querySelector('option[value="' + from + '"]')) fromEl.value = from;
      if (to && toEl.querySelector('option[value="' + to + '"]')) toEl.value = to;
      fromEl.dispatchEvent(new Event('change'));
      document.getElementById('calculator').scrollIntoView({ behavior: 'smooth' });
    });
  });
});
</script>

<?php require __DIR__ . '/templates/footer.php'; ?>
