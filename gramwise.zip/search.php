<?php
require_once __DIR__ . '/includes/bootstrap.php';

$q = trim((string) ($_GET['q'] ?? ''));
$results = ['ingredients' => [], 'articles' => [], 'pages' => []];

if ($q !== '') {
    $like = '%' . $q . '%';

    $stmt = db()->prepare("SELECT name, slug, short_description FROM ingredients WHERE status = 'published' AND name LIKE :q LIMIT 10");
    $stmt->execute(['q' => $like]);
    $results['ingredients'] = $stmt->fetchAll();

    $stmt = db()->prepare("SELECT title, slug, excerpt FROM articles WHERE status = 'published' AND (title LIKE :q OR excerpt LIKE :q) LIMIT 10");
    $stmt->execute(['q' => $like]);
    $results['articles'] = $stmt->fetchAll();

    $stmt = db()->prepare("SELECT h1, full_url FROM conversion_pages WHERE status = 'published' AND h1 LIKE :q LIMIT 10");
    $stmt->execute(['q' => $like]);
    $results['pages'] = $stmt->fetchAll();
}

$page_title = ($q !== '' ? 'Search results for "' . $q . '" | ' : 'Search | ') . get_setting('site_name');
$page_robots = 'noindex,follow';
$breadcrumbs = [['label' => 'Search']];

require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <h1>Search</h1>
  <form method="get" action="/search.php" role="search" style="max-width:480px;">
    <div class="form-group">
      <label for="q" class="sr-only">Search GramWise</label>
      <input type="text" id="q" name="q" value="<?= h($q) ?>" placeholder="e.g. 100 grams flour, honey, oven temperature">
    </div>
    <button class="btn btn-primary" type="submit">Search</button>
  </form>

  <?php if ($q !== ''): ?>
    <?php $totalResults = count($results['ingredients']) + count($results['articles']) + count($results['pages']); ?>
    <p style="margin-top:20px;"><?= $totalResults ?> result<?= $totalResults === 1 ? '' : 's' ?> for "<?= h($q) ?>"</p>

    <?php if ($results['pages']): ?>
      <h2>Conversions</h2>
      <div class="card-grid">
        <?php foreach ($results['pages'] as $r): ?>
          <a class="card" href="<?= h($r['full_url']) ?>"><h3><?= h($r['h1']) ?></h3></a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if ($results['ingredients']): ?>
      <h2>Ingredients</h2>
      <div class="card-grid">
        <?php foreach ($results['ingredients'] as $r): ?>
          <a class="card" href="/ingredients/<?= h($r['slug']) ?>/"><h3><?= h($r['name']) ?></h3><p><?= h($r['short_description']) ?></p></a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if ($results['articles']): ?>
      <h2>Guides</h2>
      <div class="card-grid">
        <?php foreach ($results['articles'] as $r): ?>
          <a class="card" href="/articles/<?= h($r['slug']) ?>/"><h3><?= h($r['title']) ?></h3><p><?= h($r['excerpt']) ?></p></a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if ($totalResults === 0): ?>
      <p>No results found. Try searching for an ingredient name, or browse <a href="/converters.php">all converters</a>.</p>
    <?php endif; ?>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
