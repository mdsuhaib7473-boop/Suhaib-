<?php
require_once __DIR__ . '/includes/bootstrap.php';
$page_title = 'Privacy Policy | ' . get_setting('site_name');
$page_robots = 'index,follow';
$breadcrumbs = [['label' => 'Privacy Policy']];
require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <h1>Privacy Policy</h1>
  <p><em>Last updated: <?= date('F j, Y') ?></em></p>
  <p>This Privacy Policy explains how <?= h(get_setting('site_name')) ?> ("we", "us") collects, uses and protects information when you use this website.</p>

  <h2>Information We Collect</h2>
  <p>We may collect information you voluntarily provide, such as your name and email address when you use our contact form. We also automatically collect limited technical information (such as browser type, pages visited and approximate location) through standard web analytics tools.</p>

  <h2>Cookies &amp; Analytics</h2>
  <p>This site may use cookies for essential functionality and, where enabled, third-party analytics services (such as Google Analytics) to understand how visitors use the site. See our <a href="/cookie-policy.php">Cookie Policy</a> for details.</p>

  <h2>Advertising</h2>
  <p>If and when this site displays advertising (for example, through Google AdSense), the advertising provider may use cookies and similar technologies to serve ads based on your prior visits to this and other websites. You can learn more about how Google uses data at <a href="https://policies.google.com/technologies/partner-sites" target="_blank" rel="noopener">Google's Partner Sites policy</a>, and you can opt out of personalized advertising through <a href="https://adssettings.google.com" target="_blank" rel="noopener">Google Ads Settings</a>.</p>

  <h2>How We Use Information</h2>
  <p>We use collected information to operate and improve the site, respond to inquiries, and understand aggregate usage patterns. We do not sell your personal information.</p>

  <h2>Third-Party Links</h2>
  <p>Our site may link to third-party websites. We are not responsible for the privacy practices of those sites.</p>

  <h2>Your Choices</h2>
  <p>You can control cookies through your browser settings and opt out of personalized advertising using the tools linked above.</p>

  <h2>Contact Us</h2>
  <p>Questions about this policy can be sent to <?= h(get_setting('contact_email')) ?>.</p>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
