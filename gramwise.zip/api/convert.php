<?php
/**
 * JSON API: converts an amount between two units, optionally using
 * an ingredient's density for mass<->volume conversions.
 * Used by the JS-driven calculator (no page reload).
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/conversion.php';

header('Content-Type: application/json; charset=utf-8');

function json_fail(string $message, int $code = 400): void
{
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $message]);
    exit;
}

$amount     = filter_input(INPUT_GET, 'amount', FILTER_VALIDATE_FLOAT);
$fromSlug   = trim((string) filter_input(INPUT_GET, 'from', FILTER_UNSAFE_RAW));
$toSlug     = trim((string) filter_input(INPUT_GET, 'to', FILTER_UNSAFE_RAW));
$ingredient = trim((string) filter_input(INPUT_GET, 'ingredient', FILTER_UNSAFE_RAW));

if ($amount === false || $amount === null) {
    json_fail('Please enter a valid numeric amount.');
}
if ($fromSlug === '' || $toSlug === '') {
    json_fail('Both "from" and "to" units are required.');
}

$fromUnit = get_unit_by_slug($fromSlug);
$toUnit   = get_unit_by_slug($toSlug);

if (!$fromUnit || !$toUnit) {
    json_fail('Unknown unit specified.');
}

$density = null;
$ingredientRow = null;
if ($fromUnit['unit_type'] !== $toUnit['unit_type'] && $fromUnit['unit_type'] !== 'temperature') {
    if ($ingredient === '') {
        json_fail('Please select an ingredient to convert between weight and volume.');
    }
    $stmt = db()->prepare('SELECT * FROM ingredients WHERE slug = :s AND status = "published"');
    $stmt->execute(['s' => $ingredient]);
    $ingredientRow = $stmt->fetch();
    if (!$ingredientRow) {
        json_fail('Ingredient not found.');
    }
    $density = (float) $ingredientRow['density_g_per_ml'];
}

try {
    $result = convert_amount((float) $amount, $fromUnit, $toUnit, $density);
} catch (InvalidArgumentException $e) {
    json_fail($e->getMessage());
}

echo json_encode([
    'ok'         => true,
    'amount'     => $amount,
    'result'     => round($result, 4),
    'result_display' => format_number($result, 3),
    'from'       => ['name' => $fromUnit['name'], 'abbr' => $fromUnit['abbreviation'], 'slug' => $fromUnit['slug']],
    'to'         => ['name' => $toUnit['name'], 'abbr' => $toUnit['abbreviation'], 'slug' => $toUnit['slug']],
    'ingredient' => $ingredientRow ? ['name' => $ingredientRow['name'], 'slug' => $ingredientRow['slug']] : null,
]);
