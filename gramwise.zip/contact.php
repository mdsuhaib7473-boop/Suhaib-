<?php
require_once __DIR__ . '/includes/bootstrap.php';

$errors = [];
$sent = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    // Honeypot spam trap — real users never fill this hidden field.
    if (!empty($_POST['website'])) {
        $sent = true; // silently "succeed" for bots
    } else {
        $name = trim((string) ($_POST['name'] ?? ''));
        $email = trim((string) ($_POST['email'] ?? ''));
        $message = trim((string) ($_POST['message'] ?? ''));

        if ($name === '' || mb_strlen($name) > 150) { $errors[] = 'Please enter a valid name.'; }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors[] = 'Please enter a valid email address.'; }
        if ($message === '' || mb_strlen($message) > 5000) { $errors[] = 'Please enter a message (under 5000 characters).'; }

        if (!$errors) {
            $to = get_setting('contact_email', ADMIN_EMAIL);
            $subject = 'New contact form message — ' . get_setting('site_name');
            $body = "Name: $name\nEmail: $email\n\nMessage:\n$message";
            $headers = 'From: no-reply@' . parse_url(SITE_URL, PHP_URL_HOST) . "\r\nReply-To: " . $email;
            @mail($to, $subject, $body, $headers);
            $sent = true;
        }
    }
}

$page_title = 'Contact Us | ' . get_setting('site_name');
$page_description = 'Get in touch with the GramWise team with questions, suggestions or feedback.';
$breadcrumbs = [['label' => 'Contact Us']];

require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <h1>Contact Us</h1>
  <p>Questions, feedback, or an ingredient you'd like added? Send us a message below.</p>

  <?php if ($sent): ?>
    <div class="alert alert-success">Thanks — your message has been sent. We'll get back to you soon.</div>
  <?php else: ?>
    <?php if ($errors): ?>
      <div class="alert alert-error"><?php foreach ($errors as $e) echo h($e) . '<br>'; ?></div>
    <?php endif; ?>
    <form method="post" style="max-width:520px;">
      <?= csrf_field() ?>
      <input type="text" name="website" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px;" aria-hidden="true">
      <div class="form-group">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" required maxlength="150" value="<?= h($_POST['name'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required maxlength="150" value="<?= h($_POST['email'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label for="message">Message</label>
        <textarea id="message" name="message" required maxlength="5000"><?= h($_POST['message'] ?? '') ?></textarea>
      </div>
      <button type="submit" class="btn btn-primary">Send Message</button>
    </form>
  <?php endif; ?>

  <h2 style="margin-top:36px;">Other Ways to Reach Us</h2>
  <p>Email: <?= h(get_setting('contact_email')) ?><br>Address: <?= h(get_setting('contact_address')) ?></p>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
