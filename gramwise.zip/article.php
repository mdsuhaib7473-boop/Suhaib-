<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/templates/related-links.php';

$slug = trim((string) ($_GET['slug'] ?? ''));
$stmt = db()->prepare("SELECT a.*, u.full_name AS author_name FROM articles a LEFT JOIN users u ON u.id = a.author_id WHERE a.slug = :s AND a.status = 'published'");
$stmt->execute(['s' => $slug]);
$article = $stmt->fetch();

if (!$article) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$relatedStmt = db()->prepare("SELECT title, slug FROM articles WHERE status = 'published' AND id != :id ORDER BY published_at DESC LIMIT 3");
$relatedStmt->execute(['id' => $article['id']]);
$related = $relatedStmt->fetchAll();

$page_title = $article['seo_title'] ?: ($article['title'] . ' | ' . get_setting('site_name'));
$page_description = $article['meta_description'] ?: $article['excerpt'];
$page_canonical = $article['canonical_url'] ?: canonical_url('/articles/' . $article['slug'] . '/');
$breadcrumbs = [['label' => 'Guides', 'url' => '/articles.php'], ['label' => $article['title']]];

require __DIR__ . '/templates/header.php';
?>
<article class="section container">
  <h1><?= h($article['title']) ?></h1>
  <p class="form-hint">Published <?= h(date('F j, Y', strtotime($article['published_at'] ?? $article['created_at']))) ?><?= $article['author_name'] ? ' by ' . h($article['author_name']) : '' ?></p>
  <div class="article-body"><?= $article['body'] /* Admin-authored trusted HTML content */ ?></div>

  <?php render_related_links('More Guides', array_map(fn($r) => ['label' => $r['title'], 'url' => '/articles/' . $r['slug'] . '/'], $related)); ?>
</article>
<?php require __DIR__ . '/templates/footer.php'; ?>
