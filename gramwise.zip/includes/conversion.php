<?php
/**
 * Core conversion math.
 *
 * Mass units convert through a base of grams.
 * Volume units convert through a base of milliliters.
 * Converting between mass and volume requires an ingredient density
 * expressed in grams per milliliter (g/ml).
 * Temperature uses direct linear formulas.
 */
require_once __DIR__ . '/db.php';

function get_unit_by_slug(string $slug): ?array
{
    $stmt = db()->prepare('SELECT * FROM units WHERE slug = :s AND is_active = 1');
    $stmt->execute(['s' => $slug]);
    return $stmt->fetch() ?: null;
}

function get_unit_by_id(int $id): ?array
{
    $stmt = db()->prepare('SELECT * FROM units WHERE id = :id');
    $stmt->execute(['id' => $id]);
    return $stmt->fetch() ?: null;
}

/**
 * Convert an amount from one unit to another.
 *
 * @param float $amount   The quantity to convert.
 * @param array $fromUnit Row from `units` table.
 * @param array $toUnit   Row from `units` table.
 * @param float|null $densityGPerMl Required only when converting between mass and volume.
 * @return float
 * @throws InvalidArgumentException if a mass<->volume conversion is requested without density.
 */
function convert_amount(float $amount, array $fromUnit, array $toUnit, ?float $densityGPerMl = null): float
{
    // Temperature has its own linear formulas (not a simple multiply).
    if ($fromUnit['unit_type'] === 'temperature' || $toUnit['unit_type'] === 'temperature') {
        return convert_temperature($amount, $fromUnit['slug'], $toUnit['slug']);
    }

    if ($fromUnit['unit_type'] === $toUnit['unit_type']) {
        // Same dimension (mass->mass or volume->volume): simple factor conversion.
        $baseValue = $amount * (float) $fromUnit['to_base_factor'];
        return $baseValue / (float) $toUnit['to_base_factor'];
    }

    // Cross-dimension (mass<->volume) requires an ingredient density.
    if ($densityGPerMl === null || $densityGPerMl <= 0) {
        throw new InvalidArgumentException('An ingredient density is required to convert between weight and volume.');
    }

    if ($fromUnit['unit_type'] === 'mass' && $toUnit['unit_type'] === 'volume') {
        $grams = $amount * (float) $fromUnit['to_base_factor'];
        $ml = $grams / $densityGPerMl;
        return $ml / (float) $toUnit['to_base_factor'];
    }

    if ($fromUnit['unit_type'] === 'volume' && $toUnit['unit_type'] === 'mass') {
        $ml = $amount * (float) $fromUnit['to_base_factor'];
        $grams = $ml * $densityGPerMl;
        return $grams / (float) $toUnit['to_base_factor'];
    }

    throw new InvalidArgumentException('Unsupported unit combination.');
}

function convert_temperature(float $amount, string $fromSlug, string $toSlug): float
{
    if ($fromSlug === $toSlug) {
        return $amount;
    }
    if ($fromSlug === 'celsius' && $toSlug === 'fahrenheit') {
        return ($amount * 9 / 5) + 32;
    }
    if ($fromSlug === 'fahrenheit' && $toSlug === 'celsius') {
        return ($amount - 32) * 5 / 9;
    }
    throw new InvalidArgumentException('Unsupported temperature conversion.');
}

/** Oven temperature helper: returns Fahrenheit, Celsius, and closest UK Gas Mark. */
function oven_temperature_table(): array
{
    // [Fahrenheit, Celsius, Gas Mark, Description]
    return [
        [225, 110, '1/4', 'Very Low'],
        [250, 120, '1/2', 'Very Low'],
        [275, 140, '1',   'Low'],
        [300, 150, '2',   'Low'],
        [325, 160, '3',   'Moderate'],
        [350, 180, '4',   'Moderate'],
        [375, 190, '5',   'Moderately Hot'],
        [400, 200, '6',   'Hot'],
        [425, 220, '7',   'Hot'],
        [450, 230, '8',   'Very Hot'],
        [475, 245, '9',   'Very Hot'],
    ];
}

/** Fetch a conversion type row (with unit info joined) by slug. */
function get_conversion_type_by_slug(string $slug): ?array
{
    $stmt = db()->prepare(
        'SELECT ct.*,
                fu.name AS from_name, fu.slug AS from_slug, fu.abbreviation AS from_abbr, fu.unit_type AS from_type, fu.to_base_factor AS from_factor,
                tu.name AS to_name, tu.slug AS to_slug, tu.abbreviation AS to_abbr, tu.unit_type AS to_type, tu.to_base_factor AS to_factor
         FROM conversion_types ct
         JOIN units fu ON fu.id = ct.from_unit_id
         JOIN units tu ON tu.id = ct.to_unit_id
         WHERE ct.slug = :slug AND ct.is_active = 1'
    );
    $stmt->execute(['slug' => $slug]);
    return $stmt->fetch() ?: null;
}

/** Convenience wrapper used by the calculator/AJAX endpoint and page generator. */
function run_conversion(array $conversionType, float $amount, ?float $densityGPerMl): float
{
    $fromUnit = [
        'unit_type' => $conversionType['from_type'],
        'to_base_factor' => $conversionType['from_factor'],
        'slug' => $conversionType['from_slug'],
    ];
    $toUnit = [
        'unit_type' => $conversionType['to_type'],
        'to_base_factor' => $conversionType['to_factor'],
        'slug' => $conversionType['to_slug'],
    ];
    return convert_amount($amount, $fromUnit, $toUnit, $densityGPerMl);
}
