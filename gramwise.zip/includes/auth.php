<?php
/**
 * Admin authentication helpers.
 * Uses password_hash()/password_verify(), secure sessions, and
 * per-account login rate limiting / lockout.
 */
require_once __DIR__ . '/functions.php';

function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_name(SESSION_NAME);
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();

    // Regenerate session ID periodically to reduce fixation risk.
    if (empty($_SESSION['_created'])) {
        $_SESSION['_created'] = time();
    } elseif (time() - $_SESSION['_created'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['_created'] = time();
    }
}

function current_admin(): ?array
{
    if (empty($_SESSION['admin_user_id'])) {
        return null;
    }
    static $user = null;
    if ($user === null) {
        $stmt = db()->prepare(
            'SELECT u.*, r.name AS role_name FROM users u
             JOIN roles r ON r.id = u.role_id
             WHERE u.id = :id AND u.is_active = 1'
        );
        $stmt->execute(['id' => $_SESSION['admin_user_id']]);
        $user = $stmt->fetch() ?: null;
    }
    return $user;
}

function require_admin_login(): void
{
    if (!current_admin()) {
        redirect('/admin/login.php');
    }
}

function require_role(string ...$roles): void
{
    $user = current_admin();
    if (!$user || !in_array($user['role_name'], $roles, true)) {
        http_response_code(403);
        die('You do not have permission to access this page.');
    }
}

/**
 * Attempt to log an admin in. Returns true on success, false on failure.
 * Applies rate limiting / temporary lockout after repeated failures.
 */
function attempt_login(string $identifier, string $password): array
{
    $stmt = db()->prepare(
        'SELECT * FROM users WHERE (username = :id OR email = :id2) LIMIT 1'
    );
    $stmt->execute(['id' => $identifier, 'id2' => $identifier]);
    $user = $stmt->fetch();

    if (!$user) {
        return ['ok' => false, 'message' => 'Invalid username or password.'];
    }

    if (!empty($user['locked_until']) && strtotime($user['locked_until']) > time()) {
        $minutesLeft = ceil((strtotime($user['locked_until']) - time()) / 60);
        return ['ok' => false, 'message' => "Account temporarily locked. Try again in {$minutesLeft} minute(s)."];
    }

    if (!$user['is_active']) {
        return ['ok' => false, 'message' => 'This account has been disabled.'];
    }

    if (!password_verify($password, $user['password_hash'])) {
        $attempts = (int) $user['failed_login_attempts'] + 1;
        $lockUntil = null;
        if ($attempts >= LOGIN_MAX_ATTEMPTS) {
            $lockUntil = date('Y-m-d H:i:s', time() + (LOGIN_LOCKOUT_MINUTES * 60));
            $attempts = 0;
        }
        $upd = db()->prepare('UPDATE users SET failed_login_attempts = :a, locked_until = :l WHERE id = :id');
        $upd->execute(['a' => $attempts, 'l' => $lockUntil, 'id' => $user['id']]);
        return ['ok' => false, 'message' => 'Invalid username or password.'];
    }

    // Success: reset attempts, record login
    $upd = db()->prepare(
        'UPDATE users SET failed_login_attempts = 0, locked_until = NULL, last_login_at = NOW() WHERE id = :id'
    );
    $upd->execute(['id' => $user['id']]);

    session_regenerate_id(true);
    $_SESSION['admin_user_id'] = $user['id'];

    return ['ok' => true, 'user' => $user];
}

function logout_admin(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}
