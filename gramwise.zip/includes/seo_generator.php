<?php
/**
 * Programmatic SEO generation engine.
 * Builds slugs, URLs, conversion-table rows and unique-enough page content
 * for a (conversion type + ingredient + amount) combination.
 */
require_once __DIR__ . '/conversion.php';

/** Naive singularizer for our unit slugs (all cleanly pluralized with a trailing "s"). */
function unit_slug_word(array $conversionTypeSide, float $amount): string
{
    $slug = $conversionTypeSide['slug'];
    $type = $conversionTypeSide['type'];
    if ($type === 'temperature') {
        return $slug; // celsius / fahrenheit - no pluralization
    }
    if (abs($amount - 1.0) < 0.0000001 && substr($slug, -1) === 's') {
        return substr($slug, 0, -1);
    }
    return $slug;
}

/** Build the page slug segment, e.g. "100-grams-to-cups" or "1-cup-to-grams". */
function build_page_slug(array $conversionType, float $amount): string
{
    $fromWord = unit_slug_word(['slug' => $conversionType['from_slug'], 'type' => $conversionType['from_type']], $amount);
    $toWord = $conversionType['to_slug']; // "to" side always uses its default (plural) form
    $amountStr = format_number($amount, 3);
    return slugify($amountStr . '-' . $fromWord . '-to-' . $toWord);
}

/** Build the full front-end URL for a page. */
function build_page_url(array $conversionType, ?array $ingredient, string $pageSlug): string
{
    if ($ingredient) {
        return '/' . $conversionType['slug'] . '/' . $ingredient['slug'] . '/' . $pageSlug . '/';
    }
    return '/' . $conversionType['slug'] . '/' . $pageSlug . '/';
}

/** Generate a numeric range (inclusive) — used for both the page-amount batch and the table rows. */
function build_amount_range(float $start, float $end, float $step): array
{
    if ($step <= 0 || $end < $start) {
        return [];
    }
    $amounts = [];
    $safetyLimit = 5000; // hard ceiling so a bad input can't hang the request
    for ($v = $start; $v <= $end + 0.0000001 && count($amounts) < $safetyLimit; $v += $step) {
        $amounts[] = round($v, 4);
    }
    return $amounts;
}

/**
 * Build the varied, ingredient-specific content for a page.
 * Uses a small rotation of phrasing so batches of pages aren't identical text
 * with only the number swapped, per the "avoid thin content" requirement.
 */
function build_page_content(array $conversionType, ?array $ingredient, float $amount, float $result): array
{
    $fromName = strtolower($conversionType['from_name']);
    $toName = strtolower($conversionType['to_name']);
    $amountStr = format_number($amount, 3);
    $resultStr = format_number($result, 3);
    $ingLabel = $ingredient ? ' ' . $ingredient['name'] : '';
    $ingLower = $ingredient ? ' ' . strtolower($ingredient['name']) : '';

    $h1 = "{$amountStr} {$conversionType['from_name']}{$ingLabel} to {$conversionType['to_name']}";
    $seoTitle = "{$h1} — Exact Conversion | " . get_setting('site_name');
    $metaDescription = $ingredient
        ? "Convert {$amountStr} {$fromName} of {$ingredient['name']} to {$toName}: {$resultStr} {$toName}. Includes a full conversion table, formula and measuring tips."
        : "Convert {$amountStr} {$fromName} to {$toName}: {$resultStr} {$toName}, with a full conversion table and formula.";
    $metaDescription = mb_substr($metaDescription, 0, 300);

    $introVariants = $ingredient ? [
        "Converting {$amountStr} {$fromName} of{$ingLower} to {$toName} gives you {$resultStr} {$toName}, based on{$ingLower}'s typical density. Below you'll find the full conversion table, the formula used, and tips for measuring{$ingLower} accurately.",
        "Wondering how much {$amountStr} {$fromName} of{$ingLower} is in {$toName}? The answer is {$resultStr} {$toName}. Because{$ingLower} has its own density, this figure is specific to this ingredient rather than a generic estimate.",
        "Here's the exact answer: {$amountStr} {$fromName} of{$ingLower} equals {$resultStr} {$toName}. Read on for a full conversion table plus guidance on measuring{$ingLower} for consistent results.",
    ] : [
        "{$amountStr} {$fromName} converts to {$resultStr} {$toName}. This is a direct unit conversion based on standard measurement definitions — see the formula and table below.",
        "Need to convert {$amountStr} {$fromName} to {$toName}? The result is {$resultStr} {$toName}. Use the calculator below to convert any other amount instantly.",
    ];
    $tipsVariants = $ingredient ? [
        "For the most consistent results, weigh{$ingLower} on a digital kitchen scale rather than relying on cup measurements, especially in baking recipes where precision affects texture.",
        "If you're measuring{$ingLower} by volume, spoon it into the measuring cup or spoon and level it off with a straight edge instead of scooping directly from the container, which tends to pack it down and throw off the conversion.",
        "Keep in mind that{$ingLower}'s density can vary slightly by brand and moisture content, so treat this conversion as a close, reliable estimate for everyday cooking rather than a laboratory-exact figure.",
    ] : [
        "Double-check your measuring tools — a US cup, UK cup and metric cup are not exactly the same size, which can matter for precise recipes.",
        "For small amounts, a set of measuring spoons will generally be more accurate than trying to eyeball a fraction of a cup.",
    ];

    // Rotate variants deterministically based on the amount so the same page always
    // renders the same copy (stable for SEO) while different pages in a batch vary.
    $seed = (int) (($amount * 100) ) % count($introVariants);
    $tipSeed = (int) (($amount * 100)) % count($tipsVariants);

    return [
        'h1' => $h1,
        'seo_title' => mb_substr($seoTitle, 0, 180),
        'meta_description' => $metaDescription,
        'intro_text' => $introVariants[$seed],
        'tips_text' => $tipsVariants[$tipSeed],
    ];
}

/**
 * Preview + generate a batch of pages for a conversion type (+ optional ingredient)
 * across an amount range, plus a shared conversion table range.
 *
 * @return array{
 *   to_create: array, existing: array, urls: array
 * }
 */
function plan_page_generation(array $conversionType, ?array $ingredient, array $pageAmounts): array
{
    $toCreate = [];
    $existing = [];

    foreach ($pageAmounts as $amount) {
        $pageSlug = build_page_slug($conversionType, $amount);
        $url = build_page_url($conversionType, $ingredient, $pageSlug);

        $stmt = db()->prepare(
            'SELECT id FROM conversion_pages WHERE conversion_type_id = :ct AND amount = :amt AND ' .
            ($ingredient ? 'ingredient_id = :ing' : 'ingredient_id IS NULL')
        );
        $params = ['ct' => $conversionType['id'], 'amt' => $amount];
        if ($ingredient) { $params['ing'] = $ingredient['id']; }
        $stmt->execute($params);

        if ($stmt->fetch()) {
            $existing[] = ['amount' => $amount, 'url' => $url];
        } else {
            $toCreate[] = ['amount' => $amount, 'url' => $url, 'slug' => $pageSlug];
        }
    }

    return ['to_create' => $toCreate, 'existing' => $existing];
}

/** Actually persist the generated pages + their conversion tables. */
function generate_pages(array $conversionType, ?array $ingredient, array $toCreate, array $tableAmounts, string $status): int
{
    $density = $ingredient ? (float) $ingredient['density_g_per_ml'] : null;
    $created = 0;

    $insertPage = db()->prepare(
        'INSERT INTO conversion_pages
         (conversion_type_id, ingredient_id, amount, result, slug, full_url, seo_title, meta_description, h1, intro_text, tips_text, status)
         VALUES (:ct,:ing,:amt,:res,:slug,:url,:st,:md,:h1,:intro,:tips,:status)'
    );
    $insertValue = db()->prepare(
        'INSERT INTO conversion_values (conversion_page_id, amount, result, sort_order) VALUES (:pid,:amt,:res,:ord)'
    );

    foreach ($toCreate as $item) {
        $amount = (float) $item['amount'];
        try {
            $result = run_conversion($conversionType, $amount, $density);
        } catch (InvalidArgumentException $e) {
            continue; // skip invalid combinations rather than writing junk
        }
        $content = build_page_content($conversionType, $ingredient, $amount, $result);

        $insertPage->execute([
            'ct' => $conversionType['id'],
            'ing' => $ingredient['id'] ?? null,
            'amt' => $amount,
            'res' => $result,
            'slug' => $item['slug'],
            'url' => $item['url'],
            'st' => $content['seo_title'],
            'md' => $content['meta_description'],
            'h1' => $content['h1'],
            'intro' => $content['intro_text'],
            'tips' => $content['tips_text'],
            'status' => $status,
        ]);
        $pageId = (int) db()->lastInsertId();
        $created++;

        $order = 0;
        foreach ($tableAmounts as $tAmount) {
            try {
                $tResult = run_conversion($conversionType, (float) $tAmount, $density);
            } catch (InvalidArgumentException $e) {
                continue;
            }
            $insertValue->execute(['pid' => $pageId, 'amt' => $tAmount, 'res' => $tResult, 'ord' => $order++]);
        }
    }

    return $created;
}
