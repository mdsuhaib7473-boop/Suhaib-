<?php
require_once __DIR__ . '/db.php';

/** Escape output for safe HTML display (XSS protection). */
function h(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/** Convert a string into a URL-safe slug. */
function slugify(string $text): string
{
    $text = trim($text);
    $text = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text) ?: $text;
    $text = strtolower($text);
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    $text = trim($text, '-');
    $text = preg_replace('/-+/', '-', $text);
    return $text ?: 'n-a';
}

/** Format a number for display, trimming unnecessary trailing zeros. */
function format_number(float $num, int $maxDecimals = 2): string
{
    if ($num == floor($num)) {
        return number_format($num, 0);
    }
    $formatted = number_format($num, $maxDecimals);
    // trim trailing zeros but keep at least 1 decimal digit if not whole
    $formatted = rtrim($formatted, '0');
    $formatted = rtrim($formatted, '.');
    return $formatted;
}

/** Redirect helper. */
function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

/** Flash message helpers (stored in session, shown once). */
function flash_set(string $type, string $message): void
{
    $_SESSION['flash'][$type][] = $message;
}

function flash_get_all(): array
{
    $flash = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flash;
}

/** Site settings cache (read from site_settings table). */
function get_setting(string $key, string $default = ''): string
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        $stmt = db()->query('SELECT setting_key, setting_value FROM site_settings');
        foreach ($stmt->fetchAll() as $row) {
            $cache[$row['setting_key']] = $row['setting_value'];
        }
    }
    return $cache[$key] ?? $default;
}

function set_setting(string $key, string $value): void
{
    $stmt = db()->prepare(
        'INSERT INTO site_settings (setting_key, setting_value) VALUES (:k, :v)
         ON DUPLICATE KEY UPDATE setting_value = :v2'
    );
    $stmt->execute(['k' => $key, 'v' => $value, 'v2' => $value]);
}

/** Log an admin activity event. */
function log_activity(string $action, string $details = ''): void
{
    $userId = $_SESSION['admin_user_id'] ?? null;
    $ip = $_SERVER['REMOTE_ADDR'] ?? null;
    $stmt = db()->prepare(
        'INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES (:u, :a, :d, :ip)'
    );
    $stmt->execute(['u' => $userId, 'a' => $action, 'd' => $details, 'ip' => $ip]);
}

/** Simple pagination calculator. */
function paginate(int $totalItems, int $perPage, int $currentPage): array
{
    $totalPages = max(1, (int) ceil($totalItems / $perPage));
    $currentPage = max(1, min($currentPage, $totalPages));
    $offset = ($currentPage - 1) * $perPage;
    return compact('totalItems', 'perPage', 'totalPages', 'currentPage', 'offset');
}

/** Build canonical absolute URL for the current or given path. */
function canonical_url(string $path = ''): string
{
    $path = '/' . ltrim($path, '/');
    return rtrim(SITE_URL, '/') . $path;
}
