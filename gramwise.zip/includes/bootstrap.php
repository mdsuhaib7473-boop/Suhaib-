<?php
require_once __DIR__ . '/auth.php'; // pulls in functions.php + db.php
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/conversion.php';
start_secure_session();
