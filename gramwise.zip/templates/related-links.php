<?php
/** render_related_links($title, $items) — $items: array of ['label'=>, 'url'=>] */
function render_related_links(string $title, array $items): void
{
    if (empty($items)) {
        return;
    }
    ?>
    <section class="related-section">
      <h2><?= h($title) ?></h2>
      <div class="card-grid">
        <?php foreach ($items as $item): ?>
          <a class="card" href="<?= h($item['url']) ?>"><h3><?= h($item['label']) ?></h3><?php if (!empty($item['desc'])): ?><p><?= h($item['desc']) ?></p><?php endif; ?></a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php
}
