<?php
/**
 * render_calculator()
 * Renders the interactive "kitchen scale" calculator widget.
 * $units: full list of unit rows from `units` table.
 * $ingredients: list of published ingredient rows (id, name, slug).
 * $preset: ['amount'=>, 'from'=>slug, 'to'=>slug, 'ingredient'=>slug]
 */
function render_calculator(array $units, array $ingredients, array $preset = []): void
{
    $amount = $preset['amount'] ?? 1;
    $fromSlug = $preset['from'] ?? 'grams';
    $toSlug = $preset['to'] ?? 'cups';
    $ingredientSlug = $preset['ingredient'] ?? ($ingredients[0]['slug'] ?? '');

    $grouped = ['mass' => [], 'volume' => [], 'temperature' => []];
    foreach ($units as $u) {
        $grouped[$u['unit_type']][] = $u;
    }
    ?>
    <div class="scale-card calculator-widget"
         data-api="/api/convert.php"
         data-preset-amount="<?= h((string)$amount) ?>"
         data-preset-from="<?= h($fromSlug) ?>"
         data-preset-to="<?= h($toSlug) ?>"
         data-preset-ingredient="<?= h($ingredientSlug) ?>">
      <div class="scale-readout">
        <span class="readout-value" data-role="result"><?= h((string)$amount) ?></span>
        <span class="unit-label" data-role="result-unit">grams</span>
      </div>
      <div class="calc-grid">
        <div class="calc-field">
          <label for="calc-amount">Amount</label>
          <input type="number" id="calc-amount" inputmode="decimal" step="any" min="0" value="<?= h((string)$amount) ?>">
        </div>
        <div class="calc-field">
          <label for="calc-from">From</label>
          <select id="calc-from">
            <?php foreach (['mass' => 'Weight', 'volume' => 'Volume', 'temperature' => 'Temperature'] as $type => $label): ?>
              <optgroup label="<?= h($label) ?>">
                <?php foreach ($grouped[$type] as $u): ?>
                  <option value="<?= h($u['slug']) ?>" <?= $u['slug'] === $fromSlug ? 'selected' : '' ?>><?= h($u['name']) ?></option>
                <?php endforeach; ?>
              </optgroup>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="calc-swap">
          <button type="button" class="swap-btn" id="calc-swap" aria-label="Swap units">⇄</button>
        </div>
      </div>
      <div class="calc-grid" style="margin-top:4px;">
        <div class="calc-field">
          <label for="calc-to">To</label>
          <select id="calc-to">
            <?php foreach (['mass' => 'Weight', 'volume' => 'Volume', 'temperature' => 'Temperature'] as $type => $label): ?>
              <optgroup label="<?= h($label) ?>">
                <?php foreach ($grouped[$type] as $u): ?>
                  <option value="<?= h($u['slug']) ?>" <?= $u['slug'] === $toSlug ? 'selected' : '' ?>><?= h($u['name']) ?></option>
                <?php endforeach; ?>
              </optgroup>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="calc-ingredient" id="calc-ingredient-wrap">
        <div class="calc-field">
          <label for="calc-ingredient">Ingredient (needed for weight ⇄ volume)</label>
          <select id="calc-ingredient">
            <?php foreach ($ingredients as $ing): ?>
              <option value="<?= h($ing['slug']) ?>" <?= $ing['slug'] === $ingredientSlug ? 'selected' : '' ?>><?= h($ing['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <p class="calc-note" data-role="calc-status">Calculating live as you type — no page reload needed.</p>
    </div>
    <?php
}
