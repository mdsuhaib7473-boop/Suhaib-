<?php
/**
 * Expects (optionally) these variables set before include:
 * $page_title, $page_description, $page_canonical, $page_robots,
 * $og_image, $breadcrumbs (array of ['label'=>..,'url'=>..])
 */
$page_title       = $page_title       ?? get_setting('site_name') . ' — Cooking Measurement & Conversion Tools';
$page_description = $page_description ?? 'Free kitchen calculators to convert grams, cups, tablespoons, ounces and more — accurate, ingredient-specific measurement conversions for cooking and baking.';
$page_canonical    = $page_canonical  ?? canonical_url($_SERVER['REQUEST_URI'] ?? '/');
$page_robots       = $page_robots     ?? 'index,follow';
$og_image           = $og_image ?? canonical_url('/assets/img/og-default.png');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($page_title) ?></title>
<meta name="description" content="<?= h($page_description) ?>">
<link rel="canonical" href="<?= h($page_canonical) ?>">
<meta name="robots" content="<?= h($page_robots) ?>">

<meta property="og:type" content="website">
<meta property="og:title" content="<?= h($page_title) ?>">
<meta property="og:description" content="<?= h($page_description) ?>">
<meta property="og:url" content="<?= h($page_canonical) ?>">
<meta property="og:image" content="<?= h($og_image) ?>">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?= h($page_title) ?>">
<meta name="twitter:description" content="<?= h($page_description) ?>">

<link rel="icon" href="/assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/style.css">

<?php if (get_setting('google_analytics_enabled') === '1' && get_setting('google_analytics_id')): ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?= h(get_setting('google_analytics_id')) ?>"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '<?= h(get_setting('google_analytics_id')) ?>');
</script>
<?php endif; ?>

<?php if (get_setting('google_search_console_enabled') === '1' && get_setting('google_search_console_verification')): ?>
<meta name="google-site-verification" content="<?= h(get_setting('google_search_console_verification')) ?>">
<?php endif; ?>

<?php if (get_setting('adsense_enabled') === '1' && get_setting('adsense_client_id')): ?>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=<?= h(get_setting('adsense_client_id')) ?>" crossorigin="anonymous"></script>
<?php endif; ?>

<?php $otherTags = get_setting('other_verification_tags'); if ($otherTags): ?>
<?= $otherTags /* Admin-controlled trusted setting, output as raw meta/verification tags */ ?>
<?php endif; ?>
</head>
<body>
<a href="#main-content" class="skip-link">Skip to content</a>

<header class="site-header">
  <div class="container header-inner">
    <a href="/" class="logo" aria-label="<?= h(get_setting('site_name')) ?> home">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 3h2l1 9a3 3 0 003 3 3 3 0 003-3l1-9h2l-1 9a5 5 0 01-4 4.9V21h-2v-4.1A5 5 0 015 12L4 3zm14 0a4 4 0 014 4v14h-2v-7h-2v7h-2V4a1 1 0 011-1z" fill="currentColor"/></svg>
      <span><?= h(get_setting('site_name')) ?></span>
    </a>
    <button class="nav-toggle" aria-expanded="false" aria-controls="primary-nav" aria-label="Toggle menu">
      <span></span><span></span><span></span>
    </button>
    <nav id="primary-nav" class="primary-nav">
      <a href="/">Home</a>
      <a href="/converters.php">All Converters</a>
      <a href="/ingredients.php">Ingredients</a>
      <a href="/articles.php">Guides</a>
      <a href="/about.php">About</a>
      <a href="/search.php" class="nav-search" aria-label="Search">🔎</a>
    </nav>
  </div>
</header>

<?php if (!empty($breadcrumbs)): ?>
<nav class="breadcrumbs container" aria-label="Breadcrumb">
  <ol>
    <li><a href="/">Home</a></li>
    <?php foreach ($breadcrumbs as $i => $bc): ?>
      <li><?php if (!empty($bc['url']) && $i < count($breadcrumbs) - 1): ?><a href="<?= h($bc['url']) ?>"><?= h($bc['label']) ?></a><?php else: ?><span aria-current="page"><?= h($bc['label']) ?></span><?php endif; ?></li>
    <?php endforeach; ?>
  </ol>
</nav>
<?php endif; ?>

<main id="main-content">
