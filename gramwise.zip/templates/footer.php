</main>

<footer class="site-footer">
  <div class="container footer-inner">
    <div class="footer-col">
      <div class="logo"><span><?= h(get_setting('site_name')) ?></span></div>
      <p><?= h(get_setting('site_tagline')) ?></p>
    </div>
    <div class="footer-col">
      <h3>Explore</h3>
      <a href="/converters.php">All Converters</a>
      <a href="/ingredients.php">Ingredients</a>
      <a href="/articles.php">Guides &amp; Articles</a>
      <a href="/sitemap.php">Sitemap</a>
    </div>
    <div class="footer-col">
      <h3>Company</h3>
      <a href="/about.php">About Us</a>
      <a href="/contact.php">Contact Us</a>
    </div>
    <div class="footer-col">
      <h3>Legal</h3>
      <a href="/privacy.php">Privacy Policy</a>
      <a href="/terms.php">Terms &amp; Conditions</a>
      <a href="/disclaimer.php">Disclaimer</a>
      <a href="/cookie-policy.php">Cookie Policy</a>
    </div>
  </div>
  <div class="container footer-bottom">
    <p>&copy; <?= date('Y') ?> <?= h(get_setting('site_name')) ?>. All rights reserved. All conversions are estimates for general cooking and baking purposes.</p>
  </div>
</footer>

<script src="/assets/js/main.js" defer></script>
<script src="/assets/js/calculator.js" defer></script>
</body>
</html>
