<?php
/**
 * render_faq_block($faqs) — $faqs: array of ['question'=>, 'answer'=>]
 * Only emits FAQPage structured data because the FAQs are actually
 * rendered visibly on the page (required for valid FAQ schema use).
 */
function render_faq_block(array $faqs, string $heading = 'Frequently Asked Questions'): void
{
    if (empty($faqs)) {
        return;
    }
    ?>
    <section class="faq-section">
      <h2><?= h($heading) ?></h2>
      <div class="faq-list">
        <?php foreach ($faqs as $faq): ?>
          <details class="faq-item">
            <summary><?= h($faq['question']) ?></summary>
            <p><?= nl2br(h($faq['answer'])) ?></p>
          </details>
        <?php endforeach; ?>
      </div>
    </section>
    <script type="application/ld+json">
    <?= json_encode([
        '@context' => 'https://schema.org',
        '@type' => 'FAQPage',
        'mainEntity' => array_map(function ($f) {
            return [
                '@type' => 'Question',
                'name' => $f['question'],
                'acceptedAnswer' => ['@type' => 'Answer', 'text' => $f['answer']],
            ];
        }, $faqs),
    ], JSON_UNESCAPED_SLASHES) ?>
    </script>
    <?php
}
