<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/templates/calculator.php';
require_once __DIR__ . '/templates/faq-block.php';
require_once __DIR__ . '/templates/related-links.php';

$units = db()->query('SELECT * FROM units WHERE is_active = 1 ORDER BY sort_order')->fetchAll();
$ingredients = db()->query("SELECT id, name, slug FROM ingredients WHERE status = 'published' ORDER BY name")->fetchAll();

$popularConversions = db()->query(
    "SELECT * FROM conversion_types WHERE is_active = 1 ORDER BY sort_order LIMIT 8"
)->fetchAll();

$popularIngredients = array_slice($ingredients, 0, 8);

$latestArticles = db()->query(
    "SELECT title, slug, excerpt, published_at FROM articles WHERE status = 'published' ORDER BY published_at DESC LIMIT 3"
)->fetchAll();

$homeFaqs = db()->query(
    "SELECT question, answer FROM faqs WHERE entity_type = 'global' AND status = 'published' ORDER BY sort_order LIMIT 8"
)->fetchAll();

$page_title = get_setting('site_name') . ' — Convert Cooking Measurements in Seconds';
$page_description = 'Free, accurate kitchen calculators for grams, cups, tablespoons, ounces, milliliters and more. Ingredient-specific conversions for baking and cooking.';

require __DIR__ . '/templates/header.php';
?>

<section class="hero container">
  <h1 class="hero-title">Convert Cooking Measurements in Seconds</h1>
  <p class="hero-sub">Weigh it, measure it, get it right the first time. GramWise turns grams, cups, tablespoons and ounces into exact, ingredient-aware conversions — built for real kitchens, not guesswork.</p>
  <?php render_calculator($units, $ingredients, ['amount' => 100, 'from' => 'grams', 'to' => 'cups', 'ingredient' => 'flour']); ?>
</section>

<section class="section container">
  <div class="section-head">
    <h2>Popular Conversions</h2>
    <a href="/converters.php">View all converters →</a>
  </div>
  <div class="card-grid">
    <?php foreach ($popularConversions as $c): ?>
      <a class="card" href="/converters.php#<?= h($c['slug']) ?>">
        <span class="pill"><?= h($c['category']) ?></span>
        <h3><?= h($c['name']) ?></h3>
        <p>Instant <?= h(strtolower($c['name'])) ?> conversion, with or without an ingredient.</p>
      </a>
    <?php endforeach; ?>
  </div>
</section>

<section class="section container">
  <div class="section-head">
    <h2>Popular Ingredients</h2>
    <a href="/ingredients.php">Browse all ingredients →</a>
  </div>
  <div class="card-grid">
    <?php foreach ($popularIngredients as $ing): ?>
      <a class="card" href="/ingredients/<?= h($ing['slug']) ?>/">
        <h3><?= h($ing['name']) ?></h3>
        <p>Density-based weight ⇄ volume conversions.</p>
      </a>
    <?php endforeach; ?>
  </div>
</section>

<section class="section container">
  <div class="section-head">
    <h2>Kitchen Tools</h2>
  </div>
  <div class="card-grid">
    <a class="card" href="/converters.php#celsius-to-fahrenheit"><h3>Celsius ⇄ Fahrenheit</h3><p>Fast oven and recipe temperature conversion.</p></a>
    <a class="card" href="/oven-temperatures.php"><h3>Oven Temperature Converter</h3><p>°F, °C and UK Gas Mark side by side.</p></a>
    <a class="card" href="/converters.php#cups-to-tablespoons"><h3>Cups, Tablespoons &amp; Teaspoons</h3><p>Every kitchen measurement, cross-converted.</p></a>
  </div>
</section>

<?php if ($latestArticles): ?>
<section class="section container">
  <div class="section-head">
    <h2>Latest Guides</h2>
    <a href="/articles.php">All guides →</a>
  </div>
  <div class="card-grid">
    <?php foreach ($latestArticles as $a): ?>
      <a class="card" href="/articles/<?= h($a['slug']) ?>/">
        <h3><?= h($a['title']) ?></h3>
        <p><?= h($a['excerpt']) ?></p>
      </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<section class="section container">
  <h2>Why Use GramWise?</h2>
  <div class="card-grid">
    <div class="card"><h3>Ingredient-Aware</h3><p>We use real ingredient densities, not a single generic "1 cup = X grams" number that's wrong for half of what you bake.</p></div>
    <div class="card"><h3>No Reload, No Wait</h3><p>The calculator updates instantly as you type — built for quick mid-recipe lookups.</p></div>
    <div class="card"><h3>Built for Every Recipe</h3><p>From spoon-and-level flour to packed brown sugar, our conversion tables reflect how ingredients actually behave.</p></div>
  </div>
</section>

<?php if ($homeFaqs): ?>
<section class="section container">
  <?php render_faq_block($homeFaqs); ?>
</section>
<?php endif; ?>

<?php require __DIR__ . '/templates/footer.php'; ?>
