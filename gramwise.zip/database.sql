-- ============================================================
-- GramWise - Cooking Measurement & Conversion Platform
-- Full Database Schema (MySQL 5.7+/8+)
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- Roles & Users (Admin authentication)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS roles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE,
  description VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO roles (name, description) VALUES
 ('super_admin', 'Full access to everything'),
 ('editor', 'Can manage content but not users/settings');

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  role_id INT UNSIGNED NOT NULL DEFAULT 2,
  username VARCHAR(60) NOT NULL UNIQUE,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(150) DEFAULT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  failed_login_attempts INT UNSIGNED NOT NULL DEFAULT 0,
  locked_until DATETIME DEFAULT NULL,
  last_login_at DATETIME DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (role_id) REFERENCES roles(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Units & Conversion Types
-- ------------------------------------------------------------
-- unit_type: mass | volume | temperature
CREATE TABLE IF NOT EXISTS units (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(60) NOT NULL,
  slug VARCHAR(60) NOT NULL UNIQUE,
  abbreviation VARCHAR(20) NOT NULL,
  unit_type ENUM('mass','volume','temperature') NOT NULL,
  to_base_factor DECIMAL(20,10) NOT NULL DEFAULT 1,
  -- to_base_factor: multiply amount by this to get the base unit
  -- base unit for mass = grams, base unit for volume = milliliters
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO units (name, slug, abbreviation, unit_type, to_base_factor, sort_order) VALUES
 ('Grams', 'grams', 'g', 'mass', 1, 1),
 ('Kilograms', 'kilograms', 'kg', 'mass', 1000, 2),
 ('Ounces', 'ounces', 'oz', 'mass', 28.3495, 3),
 ('Pounds', 'pounds', 'lb', 'mass', 453.592, 4),
 ('Milliliters', 'milliliters', 'ml', 'volume', 1, 10),
 ('Liters', 'liters', 'L', 'volume', 1000, 11),
 ('Cups', 'cups', 'cup', 'volume', 236.588, 12),
 ('Tablespoons', 'tablespoons', 'tbsp', 'volume', 14.7868, 13),
 ('Teaspoons', 'teaspoons', 'tsp', 'volume', 4.92892, 14),
 ('Fluid Ounces', 'fluid-ounces', 'fl oz', 'volume', 29.5735, 15),
 ('Pints', 'pints', 'pt', 'volume', 473.176, 16),
 ('Quarts', 'quarts', 'qt', 'volume', 946.353, 17),
 ('Gallons', 'gallons', 'gal', 'volume', 3785.41, 18),
 ('Celsius', 'celsius', '°C', 'temperature', 1, 20),
 ('Fahrenheit', 'fahrenheit', '°F', 'temperature', 1, 21);

-- conversion_types define a named pair e.g. "Grams to Cups"
CREATE TABLE IF NOT EXISTS conversion_types (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  slug VARCHAR(120) NOT NULL UNIQUE,
  from_unit_id INT UNSIGNED NOT NULL,
  to_unit_id INT UNSIGNED NOT NULL,
  category VARCHAR(60) NOT NULL DEFAULT 'Cooking Conversions',
  requires_ingredient TINYINT(1) NOT NULL DEFAULT 1,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (from_unit_id) REFERENCES units(id),
  FOREIGN KEY (to_unit_id) REFERENCES units(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- conversion_rules: reserved for future custom overrides (e.g. non-linear rules)
CREATE TABLE IF NOT EXISTS conversion_rules (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  conversion_type_id INT UNSIGNED NOT NULL,
  ingredient_id INT UNSIGNED DEFAULT NULL,
  formula_note VARCHAR(255) DEFAULT NULL,
  override_factor DECIMAL(20,10) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (conversion_type_id) REFERENCES conversion_types(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Categories (shared by ingredients / articles)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(100) NOT NULL UNIQUE,
  type ENUM('ingredient','article') NOT NULL DEFAULT 'ingredient',
  description VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Ingredients
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingredients (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  slug VARCHAR(120) NOT NULL UNIQUE,
  category_id INT UNSIGNED DEFAULT NULL,
  short_description VARCHAR(500) DEFAULT NULL,
  detailed_description TEXT DEFAULT NULL,
  density_g_per_ml DECIMAL(10,5) NOT NULL DEFAULT 1.00000,
  density_note VARCHAR(255) DEFAULT NULL,
  image_id INT UNSIGNED DEFAULT NULL,
  seo_title VARCHAR(180) DEFAULT NULL,
  meta_description VARCHAR(300) DEFAULT NULL,
  status ENUM('draft','published') NOT NULL DEFAULT 'draft',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Programmatic conversion pages
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conversion_pages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  conversion_type_id INT UNSIGNED NOT NULL,
  ingredient_id INT UNSIGNED DEFAULT NULL,
  amount DECIMAL(20,6) NOT NULL,
  result DECIMAL(20,6) NOT NULL,
  slug VARCHAR(255) NOT NULL,
  full_url VARCHAR(400) NOT NULL UNIQUE,
  seo_title VARCHAR(180) DEFAULT NULL,
  meta_description VARCHAR(300) DEFAULT NULL,
  h1 VARCHAR(180) DEFAULT NULL,
  intro_text TEXT DEFAULT NULL,
  tips_text TEXT DEFAULT NULL,
  status ENUM('draft','published','unpublished') NOT NULL DEFAULT 'draft',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_page (conversion_type_id, ingredient_id, amount),
  FOREIGN KEY (conversion_type_id) REFERENCES conversion_types(id) ON DELETE CASCADE,
  FOREIGN KEY (ingredient_id) REFERENCES ingredients(id) ON DELETE CASCADE,
  INDEX idx_status (status),
  INDEX idx_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- conversion_values: cached table values shown on each page (e.g. the table rows)
CREATE TABLE IF NOT EXISTS conversion_values (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  conversion_page_id INT UNSIGNED NOT NULL,
  amount DECIMAL(20,6) NOT NULL,
  result DECIMAL(20,6) NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  FOREIGN KEY (conversion_page_id) REFERENCES conversion_pages(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Articles / Blog
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS articles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  slug VARCHAR(220) NOT NULL UNIQUE,
  excerpt VARCHAR(400) DEFAULT NULL,
  body MEDIUMTEXT NOT NULL,
  featured_image_id INT UNSIGNED DEFAULT NULL,
  author_id INT UNSIGNED DEFAULT NULL,
  seo_title VARCHAR(180) DEFAULT NULL,
  meta_description VARCHAR(300) DEFAULT NULL,
  canonical_url VARCHAR(400) DEFAULT NULL,
  status ENUM('draft','published') NOT NULL DEFAULT 'draft',
  published_at DATETIME DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS article_categories (
  article_id INT UNSIGNED NOT NULL,
  category_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (article_id, category_id),
  FOREIGN KEY (article_id) REFERENCES articles(id) ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS tags (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(60) NOT NULL UNIQUE,
  slug VARCHAR(60) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS article_tags (
  article_id INT UNSIGNED NOT NULL,
  tag_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (article_id, tag_id),
  FOREIGN KEY (article_id) REFERENCES articles(id) ON DELETE CASCADE,
  FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- FAQs (global or attached to a specific entity)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS faqs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  question VARCHAR(300) NOT NULL,
  answer TEXT NOT NULL,
  entity_type ENUM('global','ingredient','conversion_page','article') NOT NULL DEFAULT 'global',
  entity_id INT UNSIGNED DEFAULT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  status ENUM('draft','published') NOT NULL DEFAULT 'published',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_entity (entity_type, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Media
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS media (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  file_name VARCHAR(255) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  path VARCHAR(400) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  size_bytes INT UNSIGNED NOT NULL DEFAULT 0,
  alt_text VARCHAR(255) DEFAULT NULL,
  uploaded_by INT UNSIGNED DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Generic SEO metadata (for static pages: home, about, etc.)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS seo_metadata (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  page_key VARCHAR(100) NOT NULL UNIQUE,
  seo_title VARCHAR(180) DEFAULT NULL,
  meta_description VARCHAR(300) DEFAULT NULL,
  og_title VARCHAR(180) DEFAULT NULL,
  og_description VARCHAR(300) DEFAULT NULL,
  og_image VARCHAR(400) DEFAULT NULL,
  robots VARCHAR(60) NOT NULL DEFAULT 'index,follow',
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Site settings (key/value, includes AdSense/Analytics toggles)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS site_settings (
  setting_key VARCHAR(100) NOT NULL PRIMARY KEY,
  setting_value TEXT DEFAULT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO site_settings (setting_key, setting_value) VALUES
 ('site_name', 'GramWise'),
 ('site_tagline', 'Smart Kitchen Measurement & Conversion'),
 ('contact_email', 'hello@example.com'),
 ('contact_address', '123 Placeholder Street, Placeholder City'),
 ('google_analytics_id', ''),
 ('google_analytics_enabled', '0'),
 ('google_search_console_verification', ''),
 ('google_search_console_enabled', '0'),
 ('adsense_client_id', ''),
 ('adsense_enabled', '0'),
 ('other_verification_tags', ''),
 ('table_step_default', '25'),
 ('table_max_rows', '15');

-- ------------------------------------------------------------
-- Redirects (for cleaning up removed programmatic pages)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS redirects (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  old_path VARCHAR(400) NOT NULL UNIQUE,
  new_path VARCHAR(400) NOT NULL,
  status_code SMALLINT UNSIGNED NOT NULL DEFAULT 301,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Activity Logs
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS activity_logs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED DEFAULT NULL,
  action VARCHAR(150) NOT NULL,
  details TEXT DEFAULT NULL,
  ip_address VARCHAR(45) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Seed: initial conversion types (matches spec section 3)
-- ------------------------------------------------------------
INSERT INTO conversion_types (name, slug, from_unit_id, to_unit_id, category, requires_ingredient, sort_order) VALUES
 ('Grams to Cups', 'grams-to-cups', 1, 7, 'Cooking Conversions', 1, 1),
 ('Cups to Grams', 'cups-to-grams', 7, 1, 'Cooking Conversions', 1, 2),
 ('Grams to Tablespoons', 'grams-to-tablespoons', 1, 8, 'Cooking Conversions', 1, 3),
 ('Tablespoons to Grams', 'tablespoons-to-grams', 8, 1, 'Cooking Conversions', 1, 4),
 ('Grams to Teaspoons', 'grams-to-teaspoons', 1, 9, 'Cooking Conversions', 1, 5),
 ('Teaspoons to Grams', 'teaspoons-to-grams', 9, 1, 'Cooking Conversions', 1, 6),
 ('Milliliters to Cups', 'milliliters-to-cups', 5, 7, 'Cooking Conversions', 0, 7),
 ('Cups to Milliliters', 'cups-to-milliliters', 7, 5, 'Cooking Conversions', 0, 8),
 ('Milliliters to Tablespoons', 'milliliters-to-tablespoons', 5, 8, 'Cooking Conversions', 0, 9),
 ('Tablespoons to Milliliters', 'tablespoons-to-milliliters', 8, 5, 'Cooking Conversions', 0, 10),
 ('Ounces to Grams', 'ounces-to-grams', 3, 1, 'Cooking Conversions', 0, 11),
 ('Grams to Ounces', 'grams-to-ounces', 1, 3, 'Cooking Conversions', 0, 12),
 ('Pounds to Grams', 'pounds-to-grams', 4, 1, 'Cooking Conversions', 0, 13),
 ('Grams to Pounds', 'grams-to-pounds', 1, 4, 'Cooking Conversions', 0, 14),
 ('Celsius to Fahrenheit', 'celsius-to-fahrenheit', 14, 15, 'Temperature', 0, 15),
 ('Fahrenheit to Celsius', 'fahrenheit-to-celsius', 15, 14, 'Temperature', 0, 16),
 ('Cups to Tablespoons', 'cups-to-tablespoons', 7, 8, 'Kitchen Measurements', 0, 17),
 ('Tablespoons to Teaspoons', 'tablespoons-to-teaspoons', 8, 9, 'Kitchen Measurements', 0, 18),
 ('Teaspoons to Milliliters', 'teaspoons-to-milliliters', 9, 5, 'Kitchen Measurements', 0, 19),
 ('Fluid Ounces to Milliliters', 'fluid-ounces-to-milliliters', 10, 5, 'Kitchen Measurements', 0, 20),
 ('Pints to Cups', 'pints-to-cups', 11, 7, 'Kitchen Measurements', 0, 21),
 ('Quarts to Cups', 'quarts-to-cups', 12, 7, 'Kitchen Measurements', 0, 22),
 ('Gallons to Cups', 'gallons-to-cups', 13, 7, 'Kitchen Measurements', 0, 23);

-- ------------------------------------------------------------
-- Seed: ingredient categories
-- ------------------------------------------------------------
INSERT INTO categories (name, slug, type, description) VALUES
 ('Flours', 'flours', 'ingredient', 'Wheat and alternative flours used in baking'),
 ('Sugars & Sweeteners', 'sugars-sweeteners', 'ingredient', 'Sugars, syrups and natural sweeteners'),
 ('Dairy & Fats', 'dairy-fats', 'ingredient', 'Butter, milk, oils and other fats'),
 ('Grains & Starches', 'grains-starches', 'ingredient', 'Rice, oats, cornstarch and similar staples'),
 ('Liquids', 'liquids', 'ingredient', 'Water and other cooking liquids'),
 ('Baking Guides', 'baking-guides', 'article', 'Articles about baking measurement techniques'),
 ('Conversion Tips', 'conversion-tips', 'article', 'General measurement conversion tips');

-- ------------------------------------------------------------
-- Seed: initial ingredients (density in g/ml, i.e. grams per 1 ml)
-- Values are commonly used culinary approximations.
-- ------------------------------------------------------------
INSERT INTO ingredients (name, slug, category_id, short_description, detailed_description, density_g_per_ml, status) VALUES
 ('All-Purpose Flour', 'flour', 1, 'The most common baking flour, spooned and leveled.', 'All-purpose flour is a wheat flour blend suited to a wide range of baked goods, from cookies to bread. Its measured weight varies significantly depending on whether it is spooned into the cup or scooped directly, which is why weighing on a kitchen scale gives the most consistent baking results.', 0.53000, 'published'),
 ('Bread Flour', 'bread-flour', 1, 'High-protein flour used for chewy, structured bread.', 'Bread flour has a higher protein content than all-purpose flour, which develops more gluten and gives bread its characteristic chew and structure.', 0.54000, 'published'),
 ('Cake Flour', 'cake-flour', 1, 'Low-protein, finely milled flour for tender cakes.', 'Cake flour is milled finer and has less protein than all-purpose flour, producing a softer, more tender crumb in cakes and delicate pastries.', 0.48000, 'published'),
 ('Sugar', 'sugar', 2, 'Standard granulated white sugar.', 'Granulated white sugar is the standard sweetener used in baking and cooking, with a fairly consistent density when measured level.', 0.85000, 'published'),
 ('Powdered Sugar', 'powdered-sugar', 2, 'Finely ground sugar used for icing and dusting.', 'Powdered (confectioners) sugar is granulated sugar ground to a fine powder and blended with a small amount of cornstarch, giving it a much lower density than granulated sugar.', 0.56000, 'published'),
 ('Brown Sugar', 'brown-sugar', 2, 'Moist sugar with molasses, typically packed when measured.', 'Brown sugar contains molasses, which gives it moisture and a tendency to clump. Recipes typically call for it to be firmly packed into the measuring cup.', 0.90000, 'published'),
 ('Butter', 'butter', 3, 'Standard salted or unsalted baking butter.', 'Butter is a dense dairy fat commonly sold in sticks marked with tablespoon measurements, making it one of the easier ingredients to portion accurately.', 0.96000, 'published'),
 ('Rice', 'rice', 4, 'Uncooked long or medium grain rice.', 'Uncooked rice has a fairly consistent density across common varieties, though grain length can cause minor variation.', 0.85000, 'published'),
 ('Oats', 'oats', 4, 'Rolled oats, uncooked.', 'Rolled oats are light and airy, so they occupy more volume relative to their weight than denser ingredients like sugar or flour.', 0.34000, 'published'),
 ('Cocoa Powder', 'cocoa-powder', 2, 'Unsweetened cocoa powder for baking.', 'Unsweetened cocoa powder is light and prone to clumping, so sifting before measuring by volume improves accuracy.', 0.51000, 'published'),
 ('Milk', 'milk', 5, 'Whole cow''s milk.', 'Milk has a density very close to water, with a very slight increase due to its fat and protein content.', 1.03000, 'published'),
 ('Water', 'water', 5, 'Plain drinking water.', 'Water is the reference liquid for density comparisons, with 1 milliliter weighing almost exactly 1 gram at room temperature.', 1.00000, 'published'),
 ('Honey', 'honey', 2, 'Thick natural sweetener.', 'Honey is notably denser and more viscous than water due to its high sugar concentration, so it weighs considerably more per cup than most liquids.', 1.42000, 'published'),
 ('Cornstarch', 'cornstarch', 4, 'Fine starch used as a thickener.', 'Cornstarch is a very fine, lightweight powder used primarily to thicken sauces, gravies and fillings.', 0.51000, 'published'),
 ('Almond Flour', 'almond-flour', 1, 'Finely ground blanched almonds.', 'Almond flour is denser and more oily than wheat flour, which affects both its measured weight and how it behaves in gluten-free baking.', 0.42000, 'published'),
 ('Salt', 'salt', 4, 'Fine table salt.', 'Table salt is dense and fine-grained; coarser salts like kosher or sea salt will weigh differently for the same volume.', 1.20000, 'published'),
 ('Oil', 'oil', 3, 'Standard vegetable or canola cooking oil.', 'Cooking oils are less dense than water, meaning a cup of oil weighs noticeably less than a cup of water or milk.', 0.92000, 'published'),
 ('Peanut Butter', 'peanut-butter', 3, 'Smooth peanut butter.', 'Peanut butter is thick and dense, and packing it into a measuring cup can affect the accuracy of volume-based measurements.', 1.09000, 'published');

SET FOREIGN_KEY_CHECKS = 1;
