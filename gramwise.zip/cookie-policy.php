<?php
require_once __DIR__ . '/includes/bootstrap.php';
$page_title = 'Cookie Policy | ' . get_setting('site_name');
$breadcrumbs = [['label' => 'Cookie Policy']];
require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <h1>Cookie Policy</h1>
  <p>This page explains how <?= h(get_setting('site_name')) ?> uses cookies and similar technologies.</p>
  <h2>What Are Cookies?</h2>
  <p>Cookies are small text files stored on your device that help websites function and, in some cases, help site owners understand how visitors use their site.</p>
  <h2>Cookies We Use</h2>
  <ul>
    <li><strong>Essential cookies</strong> — used for core site functionality such as maintaining your session and security tokens.</li>
    <li><strong>Analytics cookies</strong> — where enabled, tools such as Google Analytics may set cookies to measure site usage anonymously.</li>
    <li><strong>Advertising cookies</strong> — where enabled, advertising partners such as Google AdSense may set cookies to serve relevant ads.</li>
  </ul>
  <h2>Managing Cookies</h2>
  <p>Most browsers let you refuse or delete cookies through their settings. Disabling cookies may affect some site functionality.</p>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
