<?php
require_once __DIR__ . '/includes/bootstrap.php';

$categories = db()->query("SELECT * FROM categories WHERE type = 'ingredient' ORDER BY name")->fetchAll();
$catFilter = $_GET['category'] ?? '';

$sql = "SELECT i.*, c.name AS category_name FROM ingredients i
        LEFT JOIN categories c ON c.id = i.category_id
        WHERE i.status = 'published'";
$params = [];
if ($catFilter !== '') {
    $sql .= ' AND c.slug = :cat';
    $params['cat'] = $catFilter;
}
$sql .= ' ORDER BY i.name';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$ingredients = $stmt->fetchAll();

$page_title = 'Ingredient Measurement Guide — Grams, Cups & Density | ' . get_setting('site_name');
$page_description = 'Browse ingredient-specific measurement conversions with real density data, from flour and sugar to butter, honey and oats.';
$breadcrumbs = [['label' => 'Ingredients']];

require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <h1>Ingredient Measurement Guide</h1>
  <p>Every ingredient measures differently. Choose one below to see exact gram, cup, tablespoon and teaspoon conversions based on its real density.</p>

  <div class="admin-toolbar">
    <a href="/ingredients.php" class="btn btn-outline btn-sm <?= $catFilter === '' ? 'active' : '' ?>">All</a>
    <?php foreach ($categories as $cat): ?>
      <a href="/ingredients.php?category=<?= h($cat['slug']) ?>" class="btn btn-outline btn-sm"><?= h($cat['name']) ?></a>
    <?php endforeach; ?>
  </div>

  <div class="card-grid">
    <?php foreach ($ingredients as $ing): ?>
      <a class="card" href="/ingredients/<?= h($ing['slug']) ?>/">
        <span class="pill"><?= h($ing['category_name'] ?? 'Ingredient') ?></span>
        <h3><?= h($ing['name']) ?></h3>
        <p><?= h($ing['short_description']) ?></p>
      </a>
    <?php endforeach; ?>
    <?php if (!$ingredients): ?>
      <p>No ingredients found in this category yet.</p>
    <?php endif; ?>
  </div>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
