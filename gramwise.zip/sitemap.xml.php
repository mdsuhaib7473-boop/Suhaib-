<?php
/**
 * Dynamic XML sitemap. Excludes drafts, unpublished and noindex pages.
 * If total URLs exceed 45,000 it serves a sitemap index instead
 * (request ?part=N for a specific chunk).
 */
require_once __DIR__ . '/includes/functions.php';

const SITEMAP_CHUNK = 45000;

function sitemap_urls(): array
{
    $urls = [];
    $urls[] = ['loc' => canonical_url('/'), 'priority' => '1.0', 'changefreq' => 'weekly'];
    $urls[] = ['loc' => canonical_url('/converters.php'), 'priority' => '0.9', 'changefreq' => 'weekly'];
    $urls[] = ['loc' => canonical_url('/ingredients.php'), 'priority' => '0.8', 'changefreq' => 'weekly'];
    $urls[] = ['loc' => canonical_url('/articles.php'), 'priority' => '0.7', 'changefreq' => 'weekly'];
    $urls[] = ['loc' => canonical_url('/oven-temperatures.php'), 'priority' => '0.6', 'changefreq' => 'monthly'];
    $urls[] = ['loc' => canonical_url('/about.php'), 'priority' => '0.3', 'changefreq' => 'yearly'];
    $urls[] = ['loc' => canonical_url('/contact.php'), 'priority' => '0.3', 'changefreq' => 'yearly'];

    foreach (db()->query("SELECT slug, updated_at FROM ingredients WHERE status = 'published'") as $row) {
        $urls[] = ['loc' => canonical_url('/ingredients/' . $row['slug'] . '/'), 'lastmod' => $row['updated_at'], 'priority' => '0.7', 'changefreq' => 'monthly'];
    }
    foreach (db()->query("SELECT slug, updated_at FROM articles WHERE status = 'published'") as $row) {
        $urls[] = ['loc' => canonical_url('/articles/' . $row['slug'] . '/'), 'lastmod' => $row['updated_at'], 'priority' => '0.6', 'changefreq' => 'monthly'];
    }
    foreach (db()->query("SELECT full_url, updated_at FROM conversion_pages WHERE status = 'published'") as $row) {
        $urls[] = ['loc' => canonical_url($row['full_url']), 'lastmod' => $row['updated_at'], 'priority' => '0.5', 'changefreq' => 'monthly'];
    }

    return $urls;
}

header('Content-Type: application/xml; charset=utf-8');

$urls = sitemap_urls();
$total = count($urls);

if ($total <= SITEMAP_CHUNK) {
    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    foreach ($urls as $u) {
        echo '  <url>' . "\n";
        echo '    <loc>' . h($u['loc']) . '</loc>' . "\n";
        if (!empty($u['lastmod'])) {
            echo '    <lastmod>' . date('Y-m-d', strtotime($u['lastmod'])) . '</lastmod>' . "\n";
        }
        echo '    <changefreq>' . h($u['changefreq'] ?? 'monthly') . '</changefreq>' . "\n";
        echo '    <priority>' . h($u['priority'] ?? '0.5') . '</priority>' . "\n";
        echo '  </url>' . "\n";
    }
    echo '</urlset>';
} else {
    $part = (int) ($_GET['part'] ?? 0);
    if ($part > 0) {
        $chunk = array_slice($urls, ($part - 1) * SITEMAP_CHUNK, SITEMAP_CHUNK);
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach ($chunk as $u) {
            echo '  <url><loc>' . h($u['loc']) . '</loc></url>' . "\n";
        }
        echo '</urlset>';
    } else {
        $numParts = (int) ceil($total / SITEMAP_CHUNK);
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        for ($i = 1; $i <= $numParts; $i++) {
            echo '  <sitemap><loc>' . h(canonical_url('/sitemap.xml?part=' . $i)) . '</loc></sitemap>' . "\n";
        }
        echo '</sitemapindex>';
    }
}
