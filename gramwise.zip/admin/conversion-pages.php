<?php
require_once __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $formAction = $_POST['form_action'] ?? '';
    $ids = array_map('intval', $_POST['ids'] ?? []);

    if ($formAction === 'delete_single') {
        $delId = (int) $_POST['id'];
        db()->prepare('DELETE FROM conversion_pages WHERE id = :id')->execute(['id' => $delId]);
        log_activity('conversion_page_delete', "Deleted page #$delId");
        flash_set('success', 'Page deleted.');
    } elseif ($ids && in_array($formAction, ['bulk_publish', 'bulk_unpublish', 'bulk_draft', 'bulk_delete'], true)) {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        if ($formAction === 'bulk_delete') {
            db()->prepare("DELETE FROM conversion_pages WHERE id IN ($placeholders)")->execute($ids);
            flash_set('success', count($ids) . ' page(s) deleted.');
        } else {
            $newStatus = ['bulk_publish' => 'published', 'bulk_unpublish' => 'unpublished', 'bulk_draft' => 'draft'][$formAction];
            db()->prepare("UPDATE conversion_pages SET status = ? WHERE id IN ($placeholders)")->execute(array_merge([$newStatus], $ids));
            flash_set('success', count($ids) . " page(s) set to {$newStatus}.");
        }
        log_activity('conversion_page_bulk', "$formAction on " . count($ids) . ' pages');
    }
    redirect('/admin/conversion-pages.php' . (!empty($_GET['status']) ? '?status=' . urlencode($_GET['status']) : ''));
}

$statusFilter = $_GET['status'] ?? '';
$perPage = 30;
$currentPage = max(1, (int) ($_GET['page'] ?? 1));

$where = '1=1';
$params = [];
if (in_array($statusFilter, ['draft', 'published', 'unpublished'], true)) {
    $where .= ' AND cp.status = :status';
    $params['status'] = $statusFilter;
}

$countStmt = db()->prepare("SELECT COUNT(*) FROM conversion_pages cp WHERE $where");
$countStmt->execute($params);
$total = (int) $countStmt->fetchColumn();

$p = paginate($total, $perPage, $currentPage);

$stmt = db()->prepare(
    "SELECT cp.*, ct.name AS conv_name, i.name AS ing_name
     FROM conversion_pages cp
     JOIN conversion_types ct ON ct.id = cp.conversion_type_id
     LEFT JOIN ingredients i ON i.id = cp.ingredient_id
     WHERE $where ORDER BY cp.created_at DESC LIMIT :lim OFFSET :off"
);
foreach ($params as $k => $v) { $stmt->bindValue(":$k", $v); }
$stmt->bindValue(':lim', $p['perPage'], PDO::PARAM_INT);
$stmt->bindValue(':off', $p['offset'], PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll();

$admin_page_title = 'Conversion Pages';
$admin_active = 'conv-pages';
require __DIR__ . '/_header.php';
?>
<div class="admin-toolbar">
  <a href="/admin/conversion-pages.php" class="btn btn-outline btn-sm">All</a>
  <a href="/admin/conversion-pages.php?status=published" class="btn btn-outline btn-sm">Published</a>
  <a href="/admin/conversion-pages.php?status=draft" class="btn btn-outline btn-sm">Draft</a>
  <a href="/admin/conversion-pages.php?status=unpublished" class="btn btn-outline btn-sm">Unpublished</a>
  <a href="/admin/seo-generator.php" class="btn btn-primary btn-sm">+ Generate New Pages</a>
</div>

<form method="post">
  <?= csrf_field() ?>
  <div class="admin-toolbar">
    <button type="submit" name="form_action" value="bulk_publish" class="btn btn-secondary btn-sm">Bulk Publish</button>
    <button type="submit" name="form_action" value="bulk_unpublish" class="btn btn-outline btn-sm">Bulk Unpublish</button>
    <button type="submit" name="form_action" value="bulk_draft" class="btn btn-outline btn-sm">Bulk → Draft</button>
    <button type="submit" name="form_action" value="bulk_delete" class="btn btn-danger btn-sm" onclick="return confirm('Delete all selected pages? This cannot be undone.');">Bulk Delete</button>
  </div>
  <table class="admin-table">
    <thead><tr><th><input type="checkbox" onclick="document.querySelectorAll('.row-check').forEach(c=>c.checked=this.checked)"></th><th>Page</th><th>Conversion</th><th>Ingredient</th><th>Result</th><th>Status</th><th>URL</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><input class="row-check" type="checkbox" name="ids[]" value="<?= $r['id'] ?>"></td>
          <td><?= h($r['h1']) ?></td>
          <td><?= h($r['conv_name']) ?></td>
          <td><?= h($r['ing_name'] ?? '—') ?></td>
          <td><?= h(format_number((float)$r['amount'])) ?> → <?= h(format_number((float)$r['result'], 3)) ?></td>
          <td><span class="badge badge-<?= $r['status'] === 'published' ? 'published' : 'draft' ?>"><?= h($r['status']) ?></span></td>
          <td><a href="<?= h($r['full_url']) ?>" target="_blank" rel="noopener">View ↗</a></td>
          <td>
            <button form="del-<?= $r['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this page?');">Delete</button>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="8">No conversion pages yet. <a href="/admin/seo-generator.php">Generate some →</a></td></tr><?php endif; ?>
    </tbody>
  </table>
</form>

<?php foreach ($rows as $r): ?>
<form id="del-<?= $r['id'] ?>" method="post" style="display:none;">
  <?= csrf_field() ?>
  <input type="hidden" name="form_action" value="delete_single">
  <input type="hidden" name="id" value="<?= $r['id'] ?>">
</form>
<?php endforeach; ?>

<?php if ($p['totalPages'] > 1): ?>
<div class="pagination">
  <?php for ($i = 1; $i <= $p['totalPages']; $i++): ?>
    <a href="?page=<?= $i ?><?= $statusFilter ? '&status=' . h($statusFilter) : '' ?>" class="<?= $i === $p['currentPage'] ? 'current' : '' ?>"><?= $i ?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>
<?php require __DIR__ . '/_footer.php'; ?>
