<?php
require_once __DIR__ . '/bootstrap.php';

$counts = [
    'Ingredients' => (int) db()->query("SELECT COUNT(*) FROM ingredients WHERE status='published'")->fetchColumn(),
    'Articles' => (int) db()->query("SELECT COUNT(*) FROM articles WHERE status='published'")->fetchColumn(),
    'Conversion Pages' => (int) db()->query("SELECT COUNT(*) FROM conversion_pages WHERE status='published'")->fetchColumn(),
];
$total = array_sum($counts) + 7; // + static pages

$admin_page_title = 'Sitemap';
$admin_active = 'sitemap';
require __DIR__ . '/_header.php';
?>
<p>The XML sitemap is generated automatically and always reflects the current set of published, non-draft content — there's nothing to manually regenerate.</p>
<div class="stat-grid">
  <?php foreach ($counts as $label => $num): ?>
    <div class="stat-card"><div class="num"><?= number_format($num) ?></div><div class="label"><?= h($label) ?></div></div>
  <?php endforeach; ?>
  <div class="stat-card"><div class="num"><?= number_format($total) ?></div><div class="label">Total URLs in Sitemap</div></div>
</div>
<p><a class="btn btn-primary btn-sm" href="/sitemap.xml" target="_blank" rel="noopener">View Live sitemap.xml ↗</a>
<a class="btn btn-outline btn-sm" href="/sitemap.php" target="_blank" rel="noopener">View Human-Readable Sitemap ↗</a></p>
<p class="form-hint">Sitemaps automatically split into an index once the URL count exceeds 45,000, as required by search engines.</p>
<?php require __DIR__ . '/_footer.php'; ?>
