<?php
require_once __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $formAction = $_POST['form_action'] ?? '';
    if ($formAction === 'delete') {
        db()->prepare('DELETE FROM categories WHERE id = :id')->execute(['id' => (int) $_POST['id']]);
        flash_set('success', 'Category deleted.');
    } elseif ($formAction === 'save') {
        $name = trim((string) $_POST['name']);
        $slug = slugify(trim((string) $_POST['slug']) ?: $name);
        $type = in_array($_POST['type'] ?? '', ['ingredient', 'article'], true) ? $_POST['type'] : 'ingredient';
        $desc = trim((string) $_POST['description']);
        if ($name !== '') {
            db()->prepare('INSERT INTO categories (name, slug, type, description) VALUES (:n,:s,:t,:d)')
                ->execute(['n' => $name, 's' => $slug, 't' => $type, 'd' => $desc]);
            flash_set('success', 'Category created.');
        } else {
            flash_set('error', 'Name is required.');
        }
    }
    redirect('/admin/categories.php');
}

$admin_page_title = 'Categories';
$admin_active = 'categories';
require __DIR__ . '/_header.php';
$rows = db()->query('SELECT * FROM categories ORDER BY type, name')->fetchAll();
?>
<h2>Add Category</h2>
<form method="post" style="max-width:520px;">
  <?= csrf_field() ?>
  <input type="hidden" name="form_action" value="save">
  <div class="form-group"><label>Name</label><input type="text" name="name" required></div>
  <div class="form-group"><label>Slug (optional)</label><input type="text" name="slug"></div>
  <div class="form-group"><label>Type</label>
    <select name="type"><option value="ingredient">Ingredient</option><option value="article">Article</option></select>
  </div>
  <div class="form-group"><label>Description</label><input type="text" name="description"></div>
  <button class="btn btn-primary" type="submit">Add Category</button>
</form>

<h2 style="margin-top:30px;">All Categories</h2>
<table class="admin-table">
  <thead><tr><th>Name</th><th>Type</th><th>Slug</th><th></th></tr></thead>
  <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= h($r['name']) ?></td>
        <td><?= h($r['type']) ?></td>
        <td><code><?= h($r['slug']) ?></code></td>
        <td>
          <form method="post" onsubmit="return confirm('Delete this category?');">
            <?= csrf_field() ?><input type="hidden" name="form_action" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>">
            <button class="btn btn-danger btn-sm" type="submit">Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<?php require __DIR__ . '/_footer.php'; ?>
