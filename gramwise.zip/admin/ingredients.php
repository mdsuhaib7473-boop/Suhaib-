<?php
require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/_upload_helper.php';

$action = $_GET['action'] ?? 'list';
$id = (int) ($_GET['id'] ?? 0);

$categories = db()->query("SELECT * FROM categories WHERE type = 'ingredient' ORDER BY name")->fetchAll();

// ---------------- Handle POST (create/update/delete) ----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'delete') {
        $delId = (int) $_POST['id'];
        db()->prepare('DELETE FROM ingredients WHERE id = :id')->execute(['id' => $delId]);
        log_activity('ingredient_delete', "Deleted ingredient #$delId");
        flash_set('success', 'Ingredient deleted.');
        redirect('/admin/ingredients.php');
    }

    if ($formAction === 'save') {
        $name = trim((string) $_POST['name']);
        $slug = trim((string) $_POST['slug']) ?: slugify($name);
        $slug = slugify($slug);
        $categoryId = (int) $_POST['category_id'] ?: null;
        $shortDesc = trim((string) $_POST['short_description']);
        $detailedDesc = trim((string) $_POST['detailed_description']);
        $density = (float) $_POST['density_g_per_ml'];
        $seoTitle = trim((string) $_POST['seo_title']);
        $metaDesc = trim((string) $_POST['meta_description']);
        $status = in_array($_POST['status'] ?? '', ['draft', 'published'], true) ? $_POST['status'] : 'draft';
        $recordId = (int) ($_POST['id'] ?? 0);

        $errors = [];
        if ($name === '') $errors[] = 'Name is required.';
        if ($density <= 0) $errors[] = 'Density must be greater than 0.';

        $imageId = null;
        if (!empty($_FILES['image']['name'])) {
            $up = handle_media_upload($_FILES['image']);
            if ($up['ok']) {
                $imageId = $up['media_id'];
            } else {
                $errors[] = $up['error'];
            }
        }

        if (!$errors) {
            if ($recordId > 0) {
                $sql = 'UPDATE ingredients SET name=:n, slug=:s, category_id=:c, short_description=:sd, detailed_description=:dd,
                        density_g_per_ml=:den, seo_title=:st, meta_description=:md, status=:status' .
                       ($imageId ? ', image_id=:img' : '') . ' WHERE id=:id';
                $params = ['n'=>$name,'s'=>$slug,'c'=>$categoryId,'sd'=>$shortDesc,'dd'=>$detailedDesc,'den'=>$density,'st'=>$seoTitle,'md'=>$metaDesc,'status'=>$status,'id'=>$recordId];
                if ($imageId) $params['img'] = $imageId;
                db()->prepare($sql)->execute($params);
                log_activity('ingredient_update', "Updated ingredient #$recordId ($name)");
                flash_set('success', 'Ingredient updated.');
            } else {
                $sql = 'INSERT INTO ingredients (name, slug, category_id, short_description, detailed_description, density_g_per_ml, image_id, seo_title, meta_description, status)
                        VALUES (:n,:s,:c,:sd,:dd,:den,:img,:st,:md,:status)';
                db()->prepare($sql)->execute(['n'=>$name,'s'=>$slug,'c'=>$categoryId,'sd'=>$shortDesc,'dd'=>$detailedDesc,'den'=>$density,'img'=>$imageId,'st'=>$seoTitle,'md'=>$metaDesc,'status'=>$status]);
                log_activity('ingredient_create', "Created ingredient ($name)");
                flash_set('success', 'Ingredient created.');
            }
            redirect('/admin/ingredients.php');
        } else {
            foreach ($errors as $e) flash_set('error', $e);
        }
    }
}

// ---------------- Load data for view ----------------
$editRow = null;
if ($action === 'edit' && $id) {
    $stmt = db()->prepare('SELECT * FROM ingredients WHERE id = :id');
    $stmt->execute(['id' => $id]);
    $editRow = $stmt->fetch();
}

$admin_page_title = 'Ingredients';
$admin_active = 'ingredients';
require __DIR__ . '/_header.php';

if ($action === 'new' || $action === 'edit'):
?>
<a href="/admin/ingredients.php">&larr; Back to ingredients</a>
<h2><?= $editRow ? 'Edit' : 'Add' ?> Ingredient</h2>
<form method="post" enctype="multipart/form-data" style="max-width:640px;">
  <?= csrf_field() ?>
  <input type="hidden" name="form_action" value="save">
  <input type="hidden" name="id" value="<?= h((string)($editRow['id'] ?? '')) ?>">
  <div class="form-group"><label>Name</label><input type="text" name="name" required value="<?= h($editRow['name'] ?? '') ?>"></div>
  <div class="form-group"><label>Slug (leave blank to auto-generate)</label><input type="text" name="slug" value="<?= h($editRow['slug'] ?? '') ?>"></div>
  <div class="form-group"><label>Category</label>
    <select name="category_id">
      <option value="">— None —</option>
      <?php foreach ($categories as $c): ?>
        <option value="<?= $c['id'] ?>" <?= ($editRow['category_id'] ?? null) == $c['id'] ? 'selected' : '' ?>><?= h($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="form-group"><label>Short Description</label><input type="text" name="short_description" maxlength="500" value="<?= h($editRow['short_description'] ?? '') ?>"></div>
  <div class="form-group"><label>Detailed Description</label><textarea name="detailed_description"><?= h($editRow['detailed_description'] ?? '') ?></textarea></div>
  <div class="form-group"><label>Density (grams per milliliter)</label><input type="number" step="0.00001" min="0.00001" name="density_g_per_ml" required value="<?= h((string)($editRow['density_g_per_ml'] ?? '1.0')) ?>">
    <p class="form-hint">Example: water = 1.0, all-purpose flour ≈ 0.53, honey ≈ 1.42.</p>
  </div>
  <div class="form-group"><label>Image</label><input type="file" name="image" accept="image/*">
    <?php if (!empty($editRow['image_id'])): ?><p class="form-hint">An image is already set. Upload a new one to replace it.</p><?php endif; ?>
  </div>
  <div class="form-group"><label>SEO Title</label><input type="text" name="seo_title" maxlength="180" value="<?= h($editRow['seo_title'] ?? '') ?>"></div>
  <div class="form-group"><label>Meta Description</label><input type="text" name="meta_description" maxlength="300" value="<?= h($editRow['meta_description'] ?? '') ?>"></div>
  <div class="form-group"><label>Status</label>
    <select name="status">
      <option value="draft" <?= ($editRow['status'] ?? '') === 'draft' ? 'selected' : '' ?>>Draft</option>
      <option value="published" <?= ($editRow['status'] ?? '') === 'published' ? 'selected' : '' ?>>Published</option>
    </select>
  </div>
  <button class="btn btn-primary" type="submit">Save Ingredient</button>
</form>
<?php else: ?>
  <div class="admin-toolbar">
    <a href="/admin/ingredients.php?action=new" class="btn btn-primary btn-sm">+ Add Ingredient</a>
  </div>
  <table class="admin-table">
    <thead><tr><th>Name</th><th>Category</th><th>Density (g/ml)</th><th>Status</th><th>Updated</th><th></th></tr></thead>
    <tbody>
      <?php
      $rows = db()->query(
          'SELECT i.*, c.name AS cat_name FROM ingredients i LEFT JOIN categories c ON c.id = i.category_id ORDER BY i.name'
      )->fetchAll();
      foreach ($rows as $r): ?>
        <tr>
          <td><?= h($r['name']) ?></td>
          <td><?= h($r['cat_name'] ?? '—') ?></td>
          <td><?= h((string)$r['density_g_per_ml']) ?></td>
          <td><span class="badge badge-<?= $r['status'] ?>"><?= h($r['status']) ?></span></td>
          <td><?= h($r['updated_at']) ?></td>
          <td>
            <a href="/admin/ingredients.php?action=edit&id=<?= $r['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
            <form method="post" style="display:inline;" onsubmit="return confirm('Delete this ingredient? This cannot be undone.');">
              <?= csrf_field() ?>
              <input type="hidden" name="form_action" value="delete">
              <input type="hidden" name="id" value="<?= $r['id'] ?>">
              <button class="btn btn-danger btn-sm" type="submit">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="6">No ingredients yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
<?php endif; ?>
<?php require __DIR__ . '/_footer.php'; ?>
