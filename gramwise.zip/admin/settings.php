<?php
require_once __DIR__ . '/bootstrap.php';
require_admin_login();
require_role('super_admin');

$fields = [
    'site_name' => 'text', 'site_tagline' => 'text',
    'contact_email' => 'text', 'contact_address' => 'text',
    'google_analytics_id' => 'text', 'google_analytics_enabled' => 'checkbox',
    'google_search_console_verification' => 'text', 'google_search_console_enabled' => 'checkbox',
    'adsense_client_id' => 'text', 'adsense_enabled' => 'checkbox',
    'other_verification_tags' => 'textarea',
    'table_step_default' => 'text', 'table_max_rows' => 'text',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    foreach ($fields as $key => $type) {
        if ($type === 'checkbox') {
            set_setting($key, isset($_POST[$key]) ? '1' : '0');
        } else {
            set_setting($key, trim((string) ($_POST[$key] ?? '')));
        }
    }
    log_activity('settings_update', 'Site settings updated');
    flash_set('success', 'Settings saved.');
    redirect('/admin/settings.php');
}

$admin_page_title = 'Settings';
$admin_active = 'settings';
require __DIR__ . '/_header.php';
?>
<form method="post" style="max-width:640px;">
  <?= csrf_field() ?>
  <h2>Site Information</h2>
  <div class="form-group"><label>Site Name</label><input type="text" name="site_name" value="<?= h(get_setting('site_name')) ?>"></div>
  <div class="form-group"><label>Tagline</label><input type="text" name="site_tagline" value="<?= h(get_setting('site_tagline')) ?>"></div>
  <div class="form-group"><label>Contact Email</label><input type="text" name="contact_email" value="<?= h(get_setting('contact_email')) ?>"></div>
  <div class="form-group"><label>Contact Address</label><input type="text" name="contact_address" value="<?= h(get_setting('contact_address')) ?>"></div>

  <h2>Programmatic SEO Defaults</h2>
  <div class="form-group"><label>Default Table Step</label><input type="text" name="table_step_default" value="<?= h(get_setting('table_step_default')) ?>"></div>
  <div class="form-group"><label>Default Table Max Rows</label><input type="text" name="table_max_rows" value="<?= h(get_setting('table_max_rows')) ?>"></div>

  <h2>Google Analytics</h2>
  <div class="form-group"><label><input type="checkbox" name="google_analytics_enabled" <?= get_setting('google_analytics_enabled') === '1' ? 'checked' : '' ?>> Enabled</label></div>
  <div class="form-group"><label>Measurement ID (e.g. G-XXXXXXX)</label><input type="text" name="google_analytics_id" value="<?= h(get_setting('google_analytics_id')) ?>"></div>

  <h2>Google Search Console</h2>
  <div class="form-group"><label><input type="checkbox" name="google_search_console_enabled" <?= get_setting('google_search_console_enabled') === '1' ? 'checked' : '' ?>> Enabled</label></div>
  <div class="form-group"><label>Verification Code</label><input type="text" name="google_search_console_verification" value="<?= h(get_setting('google_search_console_verification')) ?>"></div>

  <h2>Google AdSense</h2>
  <p class="form-hint">Add your AdSense code once your site has been reviewed and approved. Enabling this without an approved account will not guarantee ad delivery.</p>
  <div class="form-group"><label><input type="checkbox" name="adsense_enabled" <?= get_setting('adsense_enabled') === '1' ? 'checked' : '' ?>> Enabled</label></div>
  <div class="form-group"><label>Publisher/Client ID (e.g. ca-pub-XXXXXXXXXXXXXXX)</label><input type="text" name="adsense_client_id" value="<?= h(get_setting('adsense_client_id')) ?>"></div>

  <h2>Other Verification Tags</h2>
  <div class="form-group"><label>Raw &lt;meta&gt; tags (e.g. Bing Webmaster, Pinterest)</label><textarea name="other_verification_tags"><?= h(get_setting('other_verification_tags')) ?></textarea>
    <p class="form-hint">Trusted admin-only input, output as-is in the site &lt;head&gt;.</p>
  </div>

  <button class="btn btn-primary" type="submit">Save Settings</button>
</form>
<?php require __DIR__ . '/_footer.php'; ?>
