<?php
require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/_upload_helper.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'upload' && !empty($_FILES['file']['name'])) {
        $up = handle_media_upload($_FILES['file']);
        if ($up['ok']) {
            if (!empty($_POST['alt_text'])) {
                db()->prepare('UPDATE media SET alt_text = :a WHERE id = :id')->execute(['a' => trim($_POST['alt_text']), 'id' => $up['media_id']]);
            }
            flash_set('success', 'File uploaded.');
        } else {
            flash_set('error', $up['error']);
        }
    } elseif ($formAction === 'rename') {
        $id = (int) $_POST['id'];
        $alt = trim((string) $_POST['alt_text']);
        db()->prepare('UPDATE media SET alt_text = :a WHERE id = :id')->execute(['a' => $alt, 'id' => $id]);
        flash_set('success', 'Alt text updated.');
    } elseif ($formAction === 'delete') {
        $id = (int) $_POST['id'];
        $stmt = db()->prepare('SELECT path FROM media WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        if ($row) {
            $filePath = UPLOAD_DIR . basename($row['path']);
            if (is_file($filePath)) { @unlink($filePath); }
            db()->prepare('DELETE FROM media WHERE id = :id')->execute(['id' => $id]);
            flash_set('success', 'File deleted.');
        }
    }
    redirect('/admin/media.php');
}

$search = trim((string) ($_GET['q'] ?? ''));
$sql = 'SELECT * FROM media';
$params = [];
if ($search !== '') {
    $sql .= ' WHERE original_name LIKE :q OR alt_text LIKE :q';
    $params['q'] = '%' . $search . '%';
}
$sql .= ' ORDER BY created_at DESC';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$admin_page_title = 'Media';
$admin_active = 'media';
require __DIR__ . '/_header.php';
?>
<h2>Upload New File</h2>
<form method="post" enctype="multipart/form-data" style="max-width:520px;">
  <?= csrf_field() ?>
  <input type="hidden" name="form_action" value="upload">
  <div class="form-group"><label>File (JPEG, PNG, WEBP, GIF — max 5MB)</label><input type="file" name="file" accept="image/*" required></div>
  <div class="form-group"><label>Alt Text</label><input type="text" name="alt_text" maxlength="255"></div>
  <button class="btn btn-primary" type="submit">Upload</button>
</form>

<h2 style="margin-top:30px;">Search Media</h2>
<form method="get" style="max-width:360px;margin-bottom:16px;">
  <input type="text" name="q" value="<?= h($search) ?>" placeholder="Search by filename or alt text">
</form>

<div class="card-grid">
  <?php foreach ($rows as $r): ?>
    <div class="card">
      <img src="<?= h($r['path']) ?>" alt="<?= h($r['alt_text'] ?? '') ?>" style="width:100%;height:120px;object-fit:cover;border-radius:6px;margin-bottom:8px;">
      <p style="word-break:break-all;font-size:.8rem;"><?= h($r['original_name']) ?></p>
      <form method="post" style="display:flex;gap:6px;margin-bottom:6px;">
        <?= csrf_field() ?>
        <input type="hidden" name="form_action" value="rename">
        <input type="hidden" name="id" value="<?= $r['id'] ?>">
        <input type="text" name="alt_text" value="<?= h($r['alt_text'] ?? '') ?>" placeholder="Alt text" style="flex:1;padding:6px;font-size:.8rem;">
        <button class="btn btn-outline btn-sm" type="submit">Save</button>
      </form>
      <form method="post" onsubmit="return confirm('Delete this file?');">
        <?= csrf_field() ?><input type="hidden" name="form_action" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>">
        <button class="btn btn-danger btn-sm" type="submit" style="width:100%;">Delete</button>
      </form>
    </div>
  <?php endforeach; ?>
  <?php if (!$rows): ?><p>No media uploaded yet.</p><?php endif; ?>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
