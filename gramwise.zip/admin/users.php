<?php
require_once __DIR__ . '/bootstrap.php';
require_role('super_admin');

$roles = db()->query('SELECT * FROM roles ORDER BY name')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'delete') {
        $delId = (int) $_POST['id'];
        if ($delId === (int) $admin['id']) {
            flash_set('error', 'You cannot delete your own account while logged in.');
        } else {
            db()->prepare('DELETE FROM users WHERE id = :id')->execute(['id' => $delId]);
            log_activity('user_delete', "Deleted user #$delId");
            flash_set('success', 'User deleted.');
        }
        redirect('/admin/users.php');
    }

    if ($formAction === 'toggle_active') {
        $toggleId = (int) $_POST['id'];
        db()->prepare('UPDATE users SET is_active = NOT is_active WHERE id = :id')->execute(['id' => $toggleId]);
        redirect('/admin/users.php');
    }

    if ($formAction === 'create') {
        $username = trim((string) $_POST['username']);
        $email = trim((string) $_POST['email']);
        $fullName = trim((string) $_POST['full_name']);
        $password = (string) $_POST['password'];
        $roleId = (int) $_POST['role_id'];

        $errors = [];
        if (!preg_match('/^[a-zA-Z0-9_\.\-]{3,60}$/', $username)) $errors[] = 'Username must be 3-60 characters (letters, numbers, . _ -).';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email is required.';
        if (strlen($password) < 10) $errors[] = 'Password must be at least 10 characters.';

        if (!$errors) {
            try {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                db()->prepare('INSERT INTO users (role_id, username, email, password_hash, full_name) VALUES (:r,:u,:e,:p,:f)')
                    ->execute(['r' => $roleId, 'u' => $username, 'e' => $email, 'p' => $hash, 'f' => $fullName]);
                log_activity('user_create', "Created admin user ($username)");
                flash_set('success', 'Admin user created.');
            } catch (PDOException $e) {
                $errors[] = 'That username or email is already in use.';
            }
        }
        foreach ($errors as $e) flash_set('error', $e);
        redirect('/admin/users.php');
    }
}

$admin_page_title = 'Admin Users';
$admin_active = 'users';
require __DIR__ . '/_header.php';
$rows = db()->query('SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id ORDER BY u.created_at')->fetchAll();
?>
<h2>Add Admin User</h2>
<form method="post" style="max-width:480px;">
  <?= csrf_field() ?>
  <input type="hidden" name="form_action" value="create">
  <div class="form-group"><label>Username</label><input type="text" name="username" required></div>
  <div class="form-group"><label>Email</label><input type="email" name="email" required></div>
  <div class="form-group"><label>Full Name</label><input type="text" name="full_name"></div>
  <div class="form-group"><label>Password (min 10 characters)</label><input type="password" name="password" required minlength="10"></div>
  <div class="form-group"><label>Role</label>
    <select name="role_id"><?php foreach ($roles as $r): ?><option value="<?= $r['id'] ?>"><?= h($r['name']) ?></option><?php endforeach; ?></select>
  </div>
  <button class="btn btn-primary" type="submit">Create User</button>
</form>

<h2 style="margin-top:30px;">All Admin Users</h2>
<table class="admin-table">
  <thead><tr><th>Username</th><th>Email</th><th>Role</th><th>Active</th><th>Last Login</th><th></th></tr></thead>
  <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= h($r['username']) ?></td>
        <td><?= h($r['email']) ?></td>
        <td><?= h($r['role_name']) ?></td>
        <td><?= $r['is_active'] ? 'Yes' : 'No' ?></td>
        <td><?= h($r['last_login_at'] ?? 'Never') ?></td>
        <td>
          <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="form_action" value="toggle_active"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="btn btn-outline btn-sm" type="submit"><?= $r['is_active'] ? 'Disable' : 'Enable' ?></button></form>
          <form method="post" style="display:inline;" onsubmit="return confirm('Delete this admin user?');"><?= csrf_field() ?><input type="hidden" name="form_action" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="btn btn-danger btn-sm" type="submit">Delete</button></form>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<?php require __DIR__ . '/_footer.php'; ?>
