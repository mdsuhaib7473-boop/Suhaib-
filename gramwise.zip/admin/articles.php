<?php
require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/_upload_helper.php';

$action = $_GET['action'] ?? 'list';
$id = (int) ($_GET['id'] ?? 0);
$categories = db()->query("SELECT * FROM categories WHERE type = 'article' ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'delete') {
        $delId = (int) $_POST['id'];
        db()->prepare('DELETE FROM articles WHERE id = :id')->execute(['id' => $delId]);
        log_activity('article_delete', "Deleted article #$delId");
        flash_set('success', 'Article deleted.');
        redirect('/admin/articles.php');
    }

    if ($formAction === 'save') {
        $title = trim((string) $_POST['title']);
        $slug = slugify(trim((string) $_POST['slug']) ?: $title);
        $excerpt = trim((string) $_POST['excerpt']);
        $body = $_POST['body'] ?? '';
        $seoTitle = trim((string) $_POST['seo_title']);
        $metaDesc = trim((string) $_POST['meta_description']);
        $canonical = trim((string) $_POST['canonical_url']);
        $status = in_array($_POST['status'] ?? '', ['draft', 'published'], true) ? $_POST['status'] : 'draft';
        $categoryId = (int) ($_POST['category_id'] ?? 0) ?: null;
        $recordId = (int) ($_POST['id'] ?? 0);

        $errors = [];
        if ($title === '') $errors[] = 'Title is required.';
        if (strip_tags($body) === '') $errors[] = 'Body content is required.';

        $imageId = null;
        if (!empty($_FILES['featured_image']['name'])) {
            $up = handle_media_upload($_FILES['featured_image']);
            if ($up['ok']) { $imageId = $up['media_id']; } else { $errors[] = $up['error']; }
        }

        if (!$errors) {
            $publishedAt = $status === 'published' ? date('Y-m-d H:i:s') : null;
            if ($recordId > 0) {
                $sql = 'UPDATE articles SET title=:t, slug=:s, excerpt=:e, body=:b, seo_title=:st, meta_description=:md,
                        canonical_url=:cu, status=:status' . ($imageId ? ', featured_image_id=:img' : '') .
                        (($status === 'published') ? ', published_at = COALESCE(published_at, NOW())' : '') . ' WHERE id=:id';
                $params = ['t'=>$title,'s'=>$slug,'e'=>$excerpt,'b'=>$body,'st'=>$seoTitle,'md'=>$metaDesc,'cu'=>$canonical,'status'=>$status,'id'=>$recordId];
                if ($imageId) $params['img'] = $imageId;
                db()->prepare($sql)->execute($params);
                if ($categoryId) {
                    db()->prepare('DELETE FROM article_categories WHERE article_id = :id')->execute(['id' => $recordId]);
                    db()->prepare('INSERT INTO article_categories (article_id, category_id) VALUES (:a,:c)')->execute(['a' => $recordId, 'c' => $categoryId]);
                }
                log_activity('article_update', "Updated article #$recordId ($title)");
                flash_set('success', 'Article updated.');
            } else {
                $sql = 'INSERT INTO articles (title, slug, excerpt, body, featured_image_id, author_id, seo_title, meta_description, canonical_url, status, published_at)
                        VALUES (:t,:s,:e,:b,:img,:auth,:st,:md,:cu,:status,:pub)';
                db()->prepare($sql)->execute(['t'=>$title,'s'=>$slug,'e'=>$excerpt,'b'=>$body,'img'=>$imageId,'auth'=>$admin['id'],'st'=>$seoTitle,'md'=>$metaDesc,'cu'=>$canonical,'status'=>$status,'pub'=>$publishedAt]);
                $newId = (int) db()->lastInsertId();
                if ($categoryId) {
                    db()->prepare('INSERT INTO article_categories (article_id, category_id) VALUES (:a,:c)')->execute(['a' => $newId, 'c' => $categoryId]);
                }
                log_activity('article_create', "Created article ($title)");
                flash_set('success', 'Article created.');
            }
            redirect('/admin/articles.php');
        } else {
            foreach ($errors as $e) flash_set('error', $e);
        }
    }
}

$editRow = null;
if ($action === 'edit' && $id) {
    $stmt = db()->prepare('SELECT * FROM articles WHERE id = :id');
    $stmt->execute(['id' => $id]);
    $editRow = $stmt->fetch();
}

$admin_page_title = 'Articles';
$admin_active = 'articles';
require __DIR__ . '/_header.php';

if ($action === 'new' || $action === 'edit'):
?>
<a href="/admin/articles.php">&larr; Back to articles</a>
<h2><?= $editRow ? 'Edit' : 'Write' ?> Article</h2>
<form method="post" enctype="multipart/form-data" style="max-width:760px;">
  <?= csrf_field() ?>
  <input type="hidden" name="form_action" value="save">
  <input type="hidden" name="id" value="<?= h((string)($editRow['id'] ?? '')) ?>">
  <div class="form-group"><label>Title</label><input type="text" name="title" required value="<?= h($editRow['title'] ?? '') ?>"></div>
  <div class="form-group"><label>Slug (leave blank to auto-generate)</label><input type="text" name="slug" value="<?= h($editRow['slug'] ?? '') ?>"></div>
  <div class="form-group"><label>Category</label>
    <select name="category_id">
      <option value="">— None —</option>
      <?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>"><?= h($c['name']) ?></option><?php endforeach; ?>
    </select>
  </div>
  <div class="form-group"><label>Excerpt</label><input type="text" name="excerpt" maxlength="400" value="<?= h($editRow['excerpt'] ?? '') ?>"></div>
  <div class="form-group"><label>Body (HTML supported)</label><textarea name="body" style="min-height:300px;"><?= h($editRow['body'] ?? '') ?></textarea>
    <p class="form-hint">Basic HTML tags (p, h2, h3, ul, li, strong, a) are supported. Content is trusted admin input.</p>
  </div>
  <div class="form-group"><label>Featured Image</label><input type="file" name="featured_image" accept="image/*"></div>
  <div class="form-group"><label>SEO Title</label><input type="text" name="seo_title" maxlength="180" value="<?= h($editRow['seo_title'] ?? '') ?>"></div>
  <div class="form-group"><label>Meta Description</label><input type="text" name="meta_description" maxlength="300" value="<?= h($editRow['meta_description'] ?? '') ?>"></div>
  <div class="form-group"><label>Canonical URL (optional override)</label><input type="url" name="canonical_url" value="<?= h($editRow['canonical_url'] ?? '') ?>"></div>
  <div class="form-group"><label>Status</label>
    <select name="status">
      <option value="draft" <?= ($editRow['status'] ?? '') === 'draft' ? 'selected' : '' ?>>Draft</option>
      <option value="published" <?= ($editRow['status'] ?? '') === 'published' ? 'selected' : '' ?>>Published</option>
    </select>
  </div>
  <button class="btn btn-primary" type="submit">Save Article</button>
</form>
<?php else: ?>
  <div class="admin-toolbar"><a href="/admin/articles.php?action=new" class="btn btn-primary btn-sm">+ Write Article</a></div>
  <table class="admin-table">
    <thead><tr><th>Title</th><th>Status</th><th>Published</th><th></th></tr></thead>
    <tbody>
      <?php $rows = db()->query('SELECT * FROM articles ORDER BY created_at DESC')->fetchAll(); foreach ($rows as $r): ?>
        <tr>
          <td><?= h($r['title']) ?></td>
          <td><span class="badge badge-<?= $r['status'] ?>"><?= h($r['status']) ?></span></td>
          <td><?= h($r['published_at'] ?? '—') ?></td>
          <td>
            <a href="/admin/articles.php?action=edit&id=<?= $r['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
            <form method="post" style="display:inline;" onsubmit="return confirm('Delete this article?');">
              <?= csrf_field() ?><input type="hidden" name="form_action" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>">
              <button class="btn btn-danger btn-sm" type="submit">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="4">No articles yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
<?php endif; ?>
<?php require __DIR__ . '/_footer.php'; ?>
