<?php
require_once __DIR__ . '/bootstrap.php';

$units = db()->query('SELECT * FROM units ORDER BY unit_type, sort_order')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'save_type') {
        $name = trim((string) $_POST['name']);
        $slug = slugify(trim((string) $_POST['slug']) ?: $name);
        $fromUnit = (int) $_POST['from_unit_id'];
        $toUnit = (int) $_POST['to_unit_id'];
        $category = trim((string) $_POST['category']) ?: 'Cooking Conversions';
        $requiresIngredient = isset($_POST['requires_ingredient']) ? 1 : 0;
        $recordId = (int) ($_POST['id'] ?? 0);
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        $errors = [];
        if ($name === '') $errors[] = 'Name is required.';
        if (!$fromUnit || !$toUnit) $errors[] = 'From and To units are required.';

        if (!$errors) {
            if ($recordId > 0) {
                db()->prepare(
                    'UPDATE conversion_types SET name=:n, slug=:s, from_unit_id=:f, to_unit_id=:t, category=:c, requires_ingredient=:ri, is_active=:ia WHERE id=:id'
                )->execute(['n'=>$name,'s'=>$slug,'f'=>$fromUnit,'t'=>$toUnit,'c'=>$category,'ri'=>$requiresIngredient,'ia'=>$isActive,'id'=>$recordId]);
                log_activity('conversion_type_update', "Updated conversion type #$recordId");
                flash_set('success', 'Conversion type updated.');
            } else {
                db()->prepare(
                    'INSERT INTO conversion_types (name, slug, from_unit_id, to_unit_id, category, requires_ingredient, is_active) VALUES (:n,:s,:f,:t,:c,:ri,:ia)'
                )->execute(['n'=>$name,'s'=>$slug,'f'=>$fromUnit,'t'=>$toUnit,'c'=>$category,'ri'=>$requiresIngredient,'ia'=>$isActive]);
                log_activity('conversion_type_create', "Created conversion type ($name)");
                flash_set('success', 'Conversion type created.');
            }
        } else {
            foreach ($errors as $e) flash_set('error', $e);
        }
        redirect('/admin/conversions.php');
    }

    if ($formAction === 'delete_type') {
        $delId = (int) $_POST['id'];
        db()->prepare('DELETE FROM conversion_types WHERE id = :id')->execute(['id' => $delId]);
        log_activity('conversion_type_delete', "Deleted conversion type #$delId");
        flash_set('success', 'Conversion type deleted.');
        redirect('/admin/conversions.php');
    }
}

$types = db()->query(
    'SELECT ct.*, fu.name AS from_name, tu.name AS to_name FROM conversion_types ct
     JOIN units fu ON fu.id = ct.from_unit_id JOIN units tu ON tu.id = ct.to_unit_id
     ORDER BY ct.category, ct.sort_order'
)->fetchAll();

$editId = (int) ($_GET['edit'] ?? 0);
$editRow = null;
if ($editId) {
    foreach ($types as $t) { if ($t['id'] == $editId) { $editRow = $t; break; } }
}

$admin_page_title = 'Conversions';
$admin_active = 'conversions';
require __DIR__ . '/_header.php';
?>
<h2><?= $editRow ? 'Edit' : 'Add' ?> Conversion Type</h2>
<form method="post" style="max-width:640px;">
  <?= csrf_field() ?>
  <input type="hidden" name="form_action" value="save_type">
  <input type="hidden" name="id" value="<?= h((string)($editRow['id'] ?? '')) ?>">
  <div class="form-group"><label>Name</label><input type="text" name="name" required value="<?= h($editRow['name'] ?? '') ?>" placeholder="e.g. Grams to Cups"></div>
  <div class="form-group"><label>Slug</label><input type="text" name="slug" value="<?= h($editRow['slug'] ?? '') ?>" placeholder="auto-generated if blank"></div>
  <div class="form-group"><label>From Unit</label>
    <select name="from_unit_id" required>
      <option value="">— Select —</option>
      <?php foreach ($units as $u): ?><option value="<?= $u['id'] ?>" <?= ($editRow['from_unit_id'] ?? null) == $u['id'] ? 'selected' : '' ?>><?= h($u['name']) ?> (<?= h($u['unit_type']) ?>)</option><?php endforeach; ?>
    </select>
  </div>
  <div class="form-group"><label>To Unit</label>
    <select name="to_unit_id" required>
      <option value="">— Select —</option>
      <?php foreach ($units as $u): ?><option value="<?= $u['id'] ?>" <?= ($editRow['to_unit_id'] ?? null) == $u['id'] ? 'selected' : '' ?>><?= h($u['name']) ?> (<?= h($u['unit_type']) ?>)</option><?php endforeach; ?>
    </select>
  </div>
  <div class="form-group"><label>Category</label>
    <select name="category">
      <?php foreach (['Cooking Conversions','Temperature','Kitchen Measurements'] as $cat): ?>
        <option value="<?= h($cat) ?>" <?= ($editRow['category'] ?? '') === $cat ? 'selected' : '' ?>><?= h($cat) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="form-group"><label><input type="checkbox" name="requires_ingredient" <?= ($editRow['requires_ingredient'] ?? 1) ? 'checked' : '' ?>> Requires an ingredient (needed for weight ⇄ volume conversions)</label></div>
  <div class="form-group"><label><input type="checkbox" name="is_active" <?= ($editRow['is_active'] ?? 1) ? 'checked' : '' ?>> Active</label></div>
  <button class="btn btn-primary" type="submit">Save Conversion Type</button>
  <?php if ($editRow): ?><a href="/admin/conversions.php" class="btn btn-outline">Cancel</a><?php endif; ?>
</form>

<h2 style="margin-top:36px;">All Conversion Types</h2>
<table class="admin-table">
  <thead><tr><th>Name</th><th>Category</th><th>From → To</th><th>Needs Ingredient</th><th>Status</th><th></th></tr></thead>
  <tbody>
    <?php foreach ($types as $t): ?>
      <tr>
        <td><?= h($t['name']) ?></td>
        <td><?= h($t['category']) ?></td>
        <td><?= h($t['from_name']) ?> → <?= h($t['to_name']) ?></td>
        <td><?= $t['requires_ingredient'] ? 'Yes' : 'No' ?></td>
        <td><span class="badge badge-<?= $t['is_active'] ? 'published' : 'draft' ?>"><?= $t['is_active'] ? 'active' : 'inactive' ?></span></td>
        <td>
          <a href="/admin/conversions.php?edit=<?= $t['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
          <form method="post" style="display:inline;" onsubmit="return confirm('Delete this conversion type? Any generated pages using it will also be removed.');">
            <?= csrf_field() ?>
            <input type="hidden" name="form_action" value="delete_type">
            <input type="hidden" name="id" value="<?= $t['id'] ?>">
            <button class="btn btn-danger btn-sm" type="submit">Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<h2 style="margin-top:36px;">Available Units (reference)</h2>
<table class="admin-table">
  <thead><tr><th>Name</th><th>Type</th><th>Abbreviation</th><th>Base Factor</th></tr></thead>
  <tbody>
    <?php foreach ($units as $u): ?>
      <tr><td><?= h($u['name']) ?></td><td><?= h($u['unit_type']) ?></td><td><?= h($u['abbreviation']) ?></td><td><?= h((string)$u['to_base_factor']) ?></td></tr>
    <?php endforeach; ?>
  </tbody>
</table>
<p class="form-hint">Units are seeded in the database and rarely need to change. Edit them directly via a database tool if you need to add an unusual unit.</p>

<?php require __DIR__ . '/_footer.php'; ?>
