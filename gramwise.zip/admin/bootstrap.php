<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/conversion.php';
start_secure_session();
require_admin_login();
$admin = current_admin();
