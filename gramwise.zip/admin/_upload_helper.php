<?php
/**
 * Handles a validated image upload for $_FILES['field'] and inserts a `media` row.
 * Validates real MIME type (not just extension), enforces size limit,
 * and stores the file with a randomized filename to avoid collisions/overwrites.
 */
function handle_media_upload(array $file): array
{
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => 'Upload failed (error code ' . $file['error'] . ').'];
    }
    if ($file['size'] > MAX_UPLOAD_BYTES) {
        return ['ok' => false, 'error' => 'File is too large. Maximum size is ' . (MAX_UPLOAD_BYTES / 1024 / 1024) . 'MB.'];
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!in_array($mime, ALLOWED_UPLOAD_MIME, true)) {
        return ['ok' => false, 'error' => 'Unsupported file type. Allowed: JPEG, PNG, WEBP, GIF.'];
    }

    $extMap = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $ext = $extMap[$mime];
    $fileName = bin2hex(random_bytes(16)) . '.' . $ext;
    $destPath = UPLOAD_DIR . $fileName;

    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }

    if (!move_uploaded_file($file['tmp_name'], $destPath)) {
        return ['ok' => false, 'error' => 'Could not save the uploaded file.'];
    }

    $stmt = db()->prepare(
        'INSERT INTO media (file_name, original_name, path, mime_type, size_bytes, uploaded_by) VALUES (:fn, :on, :p, :m, :sz, :u)'
    );
    $stmt->execute([
        'fn' => $fileName,
        'on' => basename($file['name']),
        'p'  => '/uploads/' . $fileName,
        'm'  => $mime,
        'sz' => $file['size'],
        'u'  => $_SESSION['admin_user_id'] ?? null,
    ]);

    return ['ok' => true, 'media_id' => (int) db()->lastInsertId(), 'path' => '/uploads/' . $fileName];
}
