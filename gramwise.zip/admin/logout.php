<?php
require_once __DIR__ . '/../includes/auth.php';
start_secure_session();
if (current_admin()) {
    log_activity('admin_logout', '');
}
logout_admin();
redirect('/admin/login.php');
