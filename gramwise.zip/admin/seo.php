<?php
require_once __DIR__ . '/bootstrap.php';

$pageKeys = [
    'home' => 'Homepage',
    'converters' => 'All Converters',
    'ingredients' => 'Ingredients Listing',
    'articles' => 'Articles Listing',
    'about' => 'About Us',
    'contact' => 'Contact Us',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $key = $_POST['page_key'] ?? '';
    if (isset($pageKeys[$key])) {
        $stmt = db()->prepare(
            'INSERT INTO seo_metadata (page_key, seo_title, meta_description, og_title, og_description, og_image, robots)
             VALUES (:k,:st,:md,:ot,:od,:oi,:r)
             ON DUPLICATE KEY UPDATE seo_title=:st2, meta_description=:md2, og_title=:ot2, og_description=:od2, og_image=:oi2, robots=:r2'
        );
        $vals = [
            'k' => $key,
            'st' => trim($_POST['seo_title'] ?? ''), 'st2' => trim($_POST['seo_title'] ?? ''),
            'md' => trim($_POST['meta_description'] ?? ''), 'md2' => trim($_POST['meta_description'] ?? ''),
            'ot' => trim($_POST['og_title'] ?? ''), 'ot2' => trim($_POST['og_title'] ?? ''),
            'od' => trim($_POST['og_description'] ?? ''), 'od2' => trim($_POST['og_description'] ?? ''),
            'oi' => trim($_POST['og_image'] ?? ''), 'oi2' => trim($_POST['og_image'] ?? ''),
            'r' => trim($_POST['robots'] ?? 'index,follow'), 'r2' => trim($_POST['robots'] ?? 'index,follow'),
        ];
        $stmt->execute($vals);
        flash_set('success', 'SEO metadata saved for ' . $pageKeys[$key] . '.');
    }
    redirect('/admin/seo.php');
}

$existing = [];
foreach (db()->query('SELECT * FROM seo_metadata') as $row) {
    $existing[$row['page_key']] = $row;
}

$admin_page_title = 'SEO';
$admin_active = 'seo';
require __DIR__ . '/_header.php';
?>
<p>Set custom SEO titles, meta descriptions and Open Graph data for core static pages. Ingredient, article and conversion pages have their own SEO fields on their respective edit screens.</p>

<?php foreach ($pageKeys as $key => $label): $row = $existing[$key] ?? []; ?>
  <h2><?= h($label) ?></h2>
  <form method="post" style="max-width:640px;margin-bottom:30px;">
    <?= csrf_field() ?>
    <input type="hidden" name="page_key" value="<?= h($key) ?>">
    <div class="form-group"><label>SEO Title</label><input type="text" name="seo_title" maxlength="180" value="<?= h($row['seo_title'] ?? '') ?>"></div>
    <div class="form-group"><label>Meta Description</label><input type="text" name="meta_description" maxlength="300" value="<?= h($row['meta_description'] ?? '') ?>"></div>
    <div class="form-group"><label>Open Graph Title</label><input type="text" name="og_title" maxlength="180" value="<?= h($row['og_title'] ?? '') ?>"></div>
    <div class="form-group"><label>Open Graph Description</label><input type="text" name="og_description" maxlength="300" value="<?= h($row['og_description'] ?? '') ?>"></div>
    <div class="form-group"><label>Open Graph Image URL</label><input type="text" name="og_image" value="<?= h($row['og_image'] ?? '') ?>"></div>
    <div class="form-group"><label>Robots</label>
      <select name="robots">
        <?php foreach (['index,follow', 'noindex,follow', 'noindex,nofollow'] as $opt): ?>
          <option value="<?= $opt ?>" <?= ($row['robots'] ?? 'index,follow') === $opt ? 'selected' : '' ?>><?= $opt ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <button class="btn btn-primary btn-sm" type="submit">Save</button>
  </form>
<?php endforeach; ?>
<?php require __DIR__ . '/_footer.php'; ?>
