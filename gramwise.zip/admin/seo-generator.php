<?php
require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/../includes/seo_generator.php';

$conversionTypes = db()->query(
    'SELECT ct.*, fu.slug AS from_slug, fu.name AS from_name, fu.unit_type AS from_type, fu.to_base_factor AS from_factor,
            tu.slug AS to_slug, tu.name AS to_name, tu.unit_type AS to_type, tu.to_base_factor AS to_factor
     FROM conversion_types ct JOIN units fu ON fu.id = ct.from_unit_id JOIN units tu ON tu.id = ct.to_unit_id
     WHERE ct.is_active = 1 ORDER BY ct.category, ct.sort_order'
)->fetchAll();
$ingredients = db()->query("SELECT * FROM ingredients WHERE status = 'published' ORDER BY name")->fetchAll();

$step = $_POST['step'] ?? 'form'; // form -> preview -> generate
$convId = (int) ($_POST['conversion_type_id'] ?? 0);
$ingId = (int) ($_POST['ingredient_id'] ?? 0);
$pageStart = (float) ($_POST['page_start'] ?? 25);
$pageEnd = (float) ($_POST['page_end'] ?? 500);
$pageStep = (float) ($_POST['page_step'] ?? 25);
$tableStart = (float) ($_POST['table_start'] ?? 25);
$tableEnd = (float) ($_POST['table_end'] ?? 1000);
$tableStep = (float) ($_POST['table_step'] ?? 25);
$status = in_array($_POST['status'] ?? '', ['draft', 'published'], true) ? $_POST['status'] : 'draft';

$conversionType = null;
foreach ($conversionTypes as $ct) { if ($ct['id'] === $convId) { $conversionType = $ct; break; } }
$ingredient = null;
if ($ingId) {
    foreach ($ingredients as $i) { if ((int)$i['id'] === $ingId) { $ingredient = $i; break; } }
}

$plan = null;
$pageAmounts = [];
$tableAmounts = [];
$errors = [];
$generatedCount = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    if (!$conversionType) {
        $errors[] = 'Please choose a conversion type.';
    } elseif ($conversionType['requires_ingredient'] && !$ingredient) {
        $errors[] = 'This conversion type requires an ingredient.';
    } elseif ($pageStep <= 0 || $pageEnd < $pageStart) {
        $errors[] = 'Please provide a valid page amount range (end must be ≥ start, step > 0).';
    } else {
        $pageAmounts = build_amount_range($pageStart, $pageEnd, $pageStep);
        $tableAmounts = build_amount_range($tableStart, $tableEnd, $tableStep);

        if (count($pageAmounts) > 500) {
            $errors[] = 'That range would generate ' . count($pageAmounts) . ' pages in one batch. Please generate in smaller batches (500 max) to review quality.';
        }
    }

    if (!$errors) {
        $plan = plan_page_generation($conversionType, $conversionType['requires_ingredient'] ? $ingredient : null, $pageAmounts);

        if ($step === 'generate') {
            $generatedCount = generate_pages($conversionType, $conversionType['requires_ingredient'] ? $ingredient : null, $plan['to_create'], $tableAmounts, $status);
            log_activity('seo_generate', "Generated {$generatedCount} pages for {$conversionType['name']}" . ($ingredient ? " / {$ingredient['name']}" : ''));
            flash_set('success', "Generated {$generatedCount} new conversion page(s). " . count($plan['existing']) . ' already existed and were skipped.');
            redirect('/admin/conversion-pages.php');
        }
    }
}

$admin_page_title = 'Programmatic SEO';
$admin_active = 'seo-gen';
require __DIR__ . '/_header.php';
?>
<p>Generate a batch of conversion pages for one conversion type (and ingredient, if required) across a range of amounts. Review the preview before confirming — no pages are created until you confirm.</p>

<?php foreach ($errors as $e): ?><div class="alert alert-error"><?= h($e) ?></div><?php endforeach; ?>

<form method="post" style="max-width:720px;">
  <?= csrf_field() ?>
  <input type="hidden" name="step" value="preview">
  <div class="form-group">
    <label>Conversion Type</label>
    <select name="conversion_type_id" required>
      <option value="">— Select —</option>
      <?php foreach ($conversionTypes as $ct): ?>
        <option value="<?= $ct['id'] ?>" <?= $convId === (int)$ct['id'] ? 'selected' : '' ?> data-requires-ingredient="<?= $ct['requires_ingredient'] ?>"><?= h($ct['name']) ?> (<?= h($ct['category']) ?>)</option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="form-group" id="ingredient-field">
    <label>Ingredient (required for weight ⇄ volume conversions)</label>
    <select name="ingredient_id">
      <option value="">— None —</option>
      <?php foreach ($ingredients as $i): ?>
        <option value="<?= $i['id'] ?>" <?= $ingId === (int)$i['id'] ? 'selected' : '' ?>><?= h($i['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="form-group">
    <label>Page Amounts — Start / End / Step</label>
    <div style="display:flex; gap:10px;">
      <input type="number" step="any" name="page_start" value="<?= h((string)$pageStart) ?>" placeholder="Start">
      <input type="number" step="any" name="page_end" value="<?= h((string)$pageEnd) ?>" placeholder="End">
      <input type="number" step="any" name="page_step" value="<?= h((string)$pageStep) ?>" placeholder="Step">
    </div>
    <p class="form-hint">Example: 25 to 500 in steps of 25 creates a separate page for 25, 50, 75 … 500.</p>
  </div>
  <div class="form-group">
    <label>Conversion Table Range (shown on each generated page)</label>
    <div style="display:flex; gap:10px;">
      <input type="number" step="any" name="table_start" value="<?= h((string)$tableStart) ?>" placeholder="Start">
      <input type="number" step="any" name="table_end" value="<?= h((string)$tableEnd) ?>" placeholder="End">
      <input type="number" step="any" name="table_step" value="<?= h((string)$tableStep) ?>" placeholder="Step">
    </div>
  </div>
  <div class="form-group">
    <label>Status for New Pages</label>
    <select name="status">
      <option value="draft" <?= $status === 'draft' ? 'selected' : '' ?>>Draft (review before publishing)</option>
      <option value="published" <?= $status === 'published' ? 'selected' : '' ?>>Published immediately</option>
    </select>
  </div>
  <button type="submit" class="btn btn-primary">Preview Pages</button>
</form>

<?php if ($plan): ?>
  <div class="section" style="padding-top:20px;">
    <h2>Preview</h2>
    <div class="stat-grid">
      <div class="stat-card"><div class="num"><?= count($plan['to_create']) ?></div><div class="label">New Pages to Create</div></div>
      <div class="stat-card"><div class="num"><?= count($plan['existing']) ?></div><div class="label">Already Exist (Skipped)</div></div>
      <div class="stat-card"><div class="num"><?= count($tableAmounts) ?></div><div class="label">Table Rows per Page</div></div>
    </div>

    <?php if ($plan['to_create']): ?>
      <h3>URLs to be Created</h3>
      <table class="admin-table">
        <thead><tr><th>Amount</th><th>URL</th></tr></thead>
        <tbody>
          <?php foreach (array_slice($plan['to_create'], 0, 50) as $item): ?>
            <tr><td><?= h(format_number($item['amount'])) ?></td><td><code><?= h($item['url']) ?></code></td></tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php if (count($plan['to_create']) > 50): ?><p class="form-hint">…and <?= count($plan['to_create']) - 50 ?> more.</p><?php endif; ?>

      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="step" value="generate">
        <input type="hidden" name="conversion_type_id" value="<?= $convId ?>">
        <input type="hidden" name="ingredient_id" value="<?= $ingId ?>">
        <input type="hidden" name="page_start" value="<?= h((string)$pageStart) ?>">
        <input type="hidden" name="page_end" value="<?= h((string)$pageEnd) ?>">
        <input type="hidden" name="page_step" value="<?= h((string)$pageStep) ?>">
        <input type="hidden" name="table_start" value="<?= h((string)$tableStart) ?>">
        <input type="hidden" name="table_end" value="<?= h((string)$tableEnd) ?>">
        <input type="hidden" name="table_step" value="<?= h((string)$tableStep) ?>">
        <input type="hidden" name="status" value="<?= h($status) ?>">
        <button type="submit" class="btn btn-secondary" onclick="return confirm('Create <?= count($plan['to_create']) ?> new page(s)?');">Confirm &amp; Generate <?= count($plan['to_create']) ?> Page(s)</button>
      </form>
    <?php else: ?>
      <p>All pages in this range already exist. Nothing to generate.</p>
    <?php endif; ?>
  </div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
  var sel = document.querySelector('select[name="conversion_type_id"]');
  var wrap = document.getElementById('ingredient-field');
  function sync() {
    var opt = sel.options[sel.selectedIndex];
    var required = opt && opt.dataset.requiresIngredient === '1';
    wrap.style.display = (sel.value === '' || required) ? '' : 'none';
  }
  sel.addEventListener('change', sync);
  sync();
});
</script>
<?php require __DIR__ . '/_footer.php'; ?>
