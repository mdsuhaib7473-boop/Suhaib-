<?php
/** Expects $admin_page_title and $admin_active (matches nav item key). */
$admin_page_title = $admin_page_title ?? 'Admin';
$admin_active = $admin_active ?? '';
$navItems = [
    'dashboard'   => ['label' => 'Dashboard', 'url' => '/admin/index.php'],
    'ingredients' => ['label' => 'Ingredients', 'url' => '/admin/ingredients.php'],
    'conversions' => ['label' => 'Conversions', 'url' => '/admin/conversions.php'],
    'seo-gen'     => ['label' => 'Programmatic SEO', 'url' => '/admin/seo-generator.php'],
    'conv-pages'  => ['label' => 'Conversion Pages', 'url' => '/admin/conversion-pages.php'],
    'articles'    => ['label' => 'Articles', 'url' => '/admin/articles.php'],
    'faqs'        => ['label' => 'FAQs', 'url' => '/admin/faqs.php'],
    'categories'  => ['label' => 'Categories', 'url' => '/admin/categories.php'],
    'media'       => ['label' => 'Media', 'url' => '/admin/media.php'],
    'seo'         => ['label' => 'SEO', 'url' => '/admin/seo.php'],
    'sitemap'     => ['label' => 'Sitemap', 'url' => '/admin/sitemap.php'],
    'settings'    => ['label' => 'Settings', 'url' => '/admin/settings.php'],
    'users'       => ['label' => 'Admin Users', 'url' => '/admin/users.php'],
    'logs'        => ['label' => 'Activity Logs', 'url' => '/admin/logs.php'],
];
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex,nofollow">
<title><?= h($admin_page_title) ?> — Admin — <?= h(get_setting('site_name')) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="admin-wrap">
  <aside class="admin-sidebar">
    <div class="brand"><?= h(get_setting('site_name')) ?> Admin</div>
    <?php foreach ($navItems as $key => $item): ?>
      <a href="<?= h($item['url']) ?>" class="<?= $admin_active === $key ? 'active' : '' ?>"><?= h($item['label']) ?></a>
    <?php endforeach; ?>
    <a href="/admin/logout.php" style="margin-top:20px;border-top:1px solid rgba(255,255,255,.1);padding-top:18px;">Logout</a>
  </aside>
  <div class="admin-main">
    <div class="admin-header">
      <h1 style="margin:0;"><?= h($admin_page_title) ?></h1>
      <div style="font-size:.85rem;color:var(--ink-soft);">Signed in as <?= h($admin['full_name'] ?: $admin['username']) ?> (<?= h($admin['role_name']) ?>)</div>
    </div>
    <?php foreach (flash_get_all() as $type => $messages): foreach ($messages as $m): ?>
      <div class="alert alert-<?= h($type) ?>"><?= h($m) ?></div>
    <?php endforeach; endforeach; ?>
