<?php
require_once __DIR__ . '/bootstrap.php';

$stats = [
    'Total Ingredients'     => (int) db()->query('SELECT COUNT(*) FROM ingredients')->fetchColumn(),
    'Conversion Types'      => (int) db()->query('SELECT COUNT(*) FROM conversion_types WHERE is_active = 1')->fetchColumn(),
    'Published Pages'       => (int) db()->query("SELECT COUNT(*) FROM conversion_pages WHERE status = 'published'")->fetchColumn(),
    'Draft Pages'           => (int) db()->query("SELECT COUNT(*) FROM conversion_pages WHERE status = 'draft'")->fetchColumn(),
    'Articles'              => (int) db()->query('SELECT COUNT(*) FROM articles')->fetchColumn(),
    'FAQs'                  => (int) db()->query('SELECT COUNT(*) FROM faqs')->fetchColumn(),
];

$recentLogs = db()->query(
    'SELECT al.*, u.username FROM activity_logs al LEFT JOIN users u ON u.id = al.user_id ORDER BY al.created_at DESC LIMIT 12'
)->fetchAll();

$admin_page_title = 'Dashboard';
$admin_active = 'dashboard';
require __DIR__ . '/_header.php';
?>
<div class="stat-grid">
  <?php foreach ($stats as $label => $num): ?>
    <div class="stat-card"><div class="num"><?= number_format($num) ?></div><div class="label"><?= h($label) ?></div></div>
  <?php endforeach; ?>
</div>

<div class="admin-toolbar">
  <a href="/admin/ingredients.php?action=new" class="btn btn-secondary btn-sm">+ Add Ingredient</a>
  <a href="/admin/seo-generator.php" class="btn btn-primary btn-sm">+ Generate Conversion Pages</a>
  <a href="/admin/articles.php?action=new" class="btn btn-outline btn-sm">+ Write Article</a>
</div>

<h2 style="margin-top:30px;">Recent Activity</h2>
<table class="admin-table">
  <thead><tr><th>Time</th><th>User</th><th>Action</th><th>Details</th></tr></thead>
  <tbody>
    <?php foreach ($recentLogs as $log): ?>
      <tr>
        <td><?= h($log['created_at']) ?></td>
        <td><?= h($log['username'] ?? 'system') ?></td>
        <td><?= h($log['action']) ?></td>
        <td><?= h($log['details']) ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$recentLogs): ?><tr><td colspan="4">No activity recorded yet.</td></tr><?php endif; ?>
  </tbody>
</table>

<?php require __DIR__ . '/_footer.php'; ?>
