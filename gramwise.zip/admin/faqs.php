<?php
require_once __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'delete') {
        db()->prepare('DELETE FROM faqs WHERE id = :id')->execute(['id' => (int) $_POST['id']]);
        flash_set('success', 'FAQ deleted.');
        redirect('/admin/faqs.php');
    }

    if ($formAction === 'save') {
        $question = trim((string) $_POST['question']);
        $answer = trim((string) $_POST['answer']);
        $entityType = in_array($_POST['entity_type'] ?? '', ['global', 'ingredient', 'conversion_page', 'article'], true) ? $_POST['entity_type'] : 'global';
        $entityId = $entityType === 'global' ? null : (int) ($_POST['entity_id'] ?? 0) ?: null;
        $order = (int) ($_POST['sort_order'] ?? 0);
        $status = in_array($_POST['status'] ?? '', ['draft', 'published'], true) ? $_POST['status'] : 'published';
        $recordId = (int) ($_POST['id'] ?? 0);

        $errors = [];
        if ($question === '') $errors[] = 'Question is required.';
        if ($answer === '') $errors[] = 'Answer is required.';

        if (!$errors) {
            if ($recordId > 0) {
                db()->prepare('UPDATE faqs SET question=:q, answer=:a, entity_type=:et, entity_id=:eid, sort_order=:so, status=:status WHERE id=:id')
                    ->execute(['q'=>$question,'a'=>$answer,'et'=>$entityType,'eid'=>$entityId,'so'=>$order,'status'=>$status,'id'=>$recordId]);
                flash_set('success', 'FAQ updated.');
            } else {
                db()->prepare('INSERT INTO faqs (question, answer, entity_type, entity_id, sort_order, status) VALUES (:q,:a,:et,:eid,:so,:status)')
                    ->execute(['q'=>$question,'a'=>$answer,'et'=>$entityType,'eid'=>$entityId,'so'=>$order,'status'=>$status]);
                flash_set('success', 'FAQ created.');
            }
            redirect('/admin/faqs.php');
        } else {
            foreach ($errors as $e) flash_set('error', $e);
        }
    }
}

$action = $_GET['action'] ?? 'list';
$id = (int) ($_GET['id'] ?? 0);
$editRow = null;
if ($action === 'edit' && $id) {
    $stmt = db()->prepare('SELECT * FROM faqs WHERE id = :id');
    $stmt->execute(['id' => $id]);
    $editRow = $stmt->fetch();
}

$admin_page_title = 'FAQs';
$admin_active = 'faqs';
require __DIR__ . '/_header.php';

if ($action === 'new' || $action === 'edit'):
?>
<a href="/admin/faqs.php">&larr; Back to FAQs</a>
<h2><?= $editRow ? 'Edit' : 'Add' ?> FAQ</h2>
<form method="post" style="max-width:640px;">
  <?= csrf_field() ?>
  <input type="hidden" name="form_action" value="save">
  <input type="hidden" name="id" value="<?= h((string)($editRow['id'] ?? '')) ?>">
  <div class="form-group"><label>Question</label><input type="text" name="question" required value="<?= h($editRow['question'] ?? '') ?>"></div>
  <div class="form-group"><label>Answer</label><textarea name="answer" required><?= h($editRow['answer'] ?? '') ?></textarea></div>
  <div class="form-group"><label>Attach To</label>
    <select name="entity_type" id="entity-type">
      <?php foreach (['global' => 'Global (site-wide)', 'ingredient' => 'Specific Ingredient', 'conversion_page' => 'Specific Conversion Page', 'article' => 'Specific Article'] as $val => $label): ?>
        <option value="<?= $val ?>" <?= ($editRow['entity_type'] ?? 'global') === $val ? 'selected' : '' ?>><?= h($label) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="form-group" id="entity-id-field">
    <label>Entity ID (Ingredient/Article/Page ID — find it in its admin list)</label>
    <input type="number" name="entity_id" value="<?= h((string)($editRow['entity_id'] ?? '')) ?>">
  </div>
  <div class="form-group"><label>Sort Order</label><input type="number" name="sort_order" value="<?= h((string)($editRow['sort_order'] ?? 0)) ?>"></div>
  <div class="form-group"><label>Status</label>
    <select name="status">
      <option value="published" <?= ($editRow['status'] ?? 'published') === 'published' ? 'selected' : '' ?>>Published (visible)</option>
      <option value="draft" <?= ($editRow['status'] ?? '') === 'draft' ? 'selected' : '' ?>>Draft (hidden)</option>
    </select>
  </div>
  <button class="btn btn-primary" type="submit">Save FAQ</button>
</form>
<script>
document.addEventListener('DOMContentLoaded', function(){
  var sel = document.getElementById('entity-type');
  var field = document.getElementById('entity-id-field');
  function sync(){ field.style.display = sel.value === 'global' ? 'none' : ''; }
  sel.addEventListener('change', sync); sync();
});
</script>
<?php else: ?>
  <div class="admin-toolbar"><a href="/admin/faqs.php?action=new" class="btn btn-primary btn-sm">+ Add FAQ</a></div>
  <table class="admin-table">
    <thead><tr><th>Question</th><th>Attached To</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <?php $rows = db()->query('SELECT * FROM faqs ORDER BY entity_type, sort_order')->fetchAll(); foreach ($rows as $r): ?>
        <tr>
          <td><?= h($r['question']) ?></td>
          <td><?= h($r['entity_type']) ?><?= $r['entity_id'] ? ' #' . $r['entity_id'] : '' ?></td>
          <td><span class="badge badge-<?= $r['status'] === 'published' ? 'published' : 'draft' ?>"><?= h($r['status']) ?></span></td>
          <td>
            <a href="/admin/faqs.php?action=edit&id=<?= $r['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
            <form method="post" style="display:inline;" onsubmit="return confirm('Delete this FAQ?');">
              <?= csrf_field() ?><input type="hidden" name="form_action" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>">
              <button class="btn btn-danger btn-sm" type="submit">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="4">No FAQs yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
<?php endif; ?>
<?php require __DIR__ . '/_footer.php'; ?>
