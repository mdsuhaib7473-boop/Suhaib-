<?php
require_once __DIR__ . '/bootstrap.php';
require_role('super_admin');

$perPage = 50;
$currentPage = max(1, (int) ($_GET['page'] ?? 1));
$total = (int) db()->query('SELECT COUNT(*) FROM activity_logs')->fetchColumn();
$p = paginate($total, $perPage, $currentPage);

$stmt = db()->prepare(
    'SELECT al.*, u.username FROM activity_logs al LEFT JOIN users u ON u.id = al.user_id
     ORDER BY al.created_at DESC LIMIT :lim OFFSET :off'
);
$stmt->bindValue(':lim', $p['perPage'], PDO::PARAM_INT);
$stmt->bindValue(':off', $p['offset'], PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll();

$admin_page_title = 'Activity Logs';
$admin_active = 'logs';
require __DIR__ . '/_header.php';
?>
<table class="admin-table">
  <thead><tr><th>Time</th><th>User</th><th>Action</th><th>Details</th><th>IP</th></tr></thead>
  <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= h($r['created_at']) ?></td>
        <td><?= h($r['username'] ?? 'system') ?></td>
        <td><?= h($r['action']) ?></td>
        <td><?= h($r['details']) ?></td>
        <td><?= h($r['ip_address'] ?? '') ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="5">No activity logged yet.</td></tr><?php endif; ?>
  </tbody>
</table>
<?php if ($p['totalPages'] > 1): ?>
<div class="pagination">
  <?php for ($i = 1; $i <= $p['totalPages']; $i++): ?>
    <a href="?page=<?= $i ?>" class="<?= $i === $p['currentPage'] ? 'current' : '' ?>"><?= $i ?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>
<?php require __DIR__ . '/_footer.php'; ?>
