<?php
require_once __DIR__ . '/includes/bootstrap.php';

$perPage = 12;
$currentPage = max(1, (int) ($_GET['page'] ?? 1));
$total = (int) db()->query("SELECT COUNT(*) FROM articles WHERE status = 'published'")->fetchColumn();
$p = paginate($total, $perPage, $currentPage);

$stmt = db()->prepare("SELECT title, slug, excerpt, published_at FROM articles WHERE status = 'published' ORDER BY published_at DESC LIMIT :lim OFFSET :off");
$stmt->bindValue(':lim', $p['perPage'], PDO::PARAM_INT);
$stmt->bindValue(':off', $p['offset'], PDO::PARAM_INT);
$stmt->execute();
$articles = $stmt->fetchAll();

$page_title = 'Cooking & Baking Measurement Guides | ' . get_setting('site_name');
$page_description = 'Practical guides on cooking measurements: how to measure flour correctly, cups vs grams, common baking mistakes and more.';
$breadcrumbs = [['label' => 'Guides']];

require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <h1>Guides &amp; Articles</h1>
  <p>Practical, no-nonsense guides to measuring and converting ingredients accurately.</p>

  <div class="card-grid">
    <?php foreach ($articles as $a): ?>
      <a class="card" href="/articles/<?= h($a['slug']) ?>/">
        <h3><?= h($a['title']) ?></h3>
        <p><?= h($a['excerpt']) ?></p>
      </a>
    <?php endforeach; ?>
    <?php if (!$articles): ?><p>No articles published yet — check back soon.</p><?php endif; ?>
  </div>

  <?php if ($p['totalPages'] > 1): ?>
  <div class="pagination">
    <?php for ($i = 1; $i <= $p['totalPages']; $i++): ?>
      <?php if ($i === $p['currentPage']): ?>
        <span class="current"><?= $i ?></span>
      <?php else: ?>
        <a href="?page=<?= $i ?>"><?= $i ?></a>
      <?php endif; ?>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
