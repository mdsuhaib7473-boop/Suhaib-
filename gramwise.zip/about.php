<?php
require_once __DIR__ . '/includes/bootstrap.php';
$page_title = 'About Us | ' . get_setting('site_name');
$page_description = 'Learn about GramWise, a free kitchen measurement and conversion tool built for home cooks and bakers.';
$breadcrumbs = [['label' => 'About Us']];
require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <h1>About <?= h(get_setting('site_name')) ?></h1>
  <p><?= h(get_setting('site_name')) ?> was built to solve a simple, everyday kitchen problem: recipes measure ingredients in cups and spoons, but those measurements aren't consistent — a cup of flour and a cup of honey don't weigh anywhere near the same amount.</p>
  <p>We built ingredient-aware conversion tools that account for real density differences, so whether you're converting grams to cups, tablespoons to milliliters, or figuring out an oven temperature in Celsius, the numbers you get are as accurate as we can make them.</p>
  <h2>Our Approach</h2>
  <p>Every conversion on this site is calculated from standard, published unit definitions and typical ingredient densities. We're upfront that these are estimates suited for everyday cooking and baking — for the most precise results in recipe development, we always recommend weighing ingredients on a digital kitchen scale.</p>
  <h2>Get in Touch</h2>
  <p>Have a suggestion for an ingredient or conversion we should add? <a href="/contact.php">Contact us</a> — we're always expanding based on what people are searching for.</p>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
