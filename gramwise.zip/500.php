<?php
http_response_code(500);
?><!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Something Went Wrong</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>body{font-family:sans-serif;text-align:center;padding:80px 20px;background:#FBF9F4;color:#2A241E;}
a{color:#3F6659;}</style></head>
<body>
<h1>Something Went Wrong</h1>
<p>We're experiencing a temporary issue. Please try again in a moment.</p>
<p><a href="/">Return to Homepage</a></p>
</body>
</html>
