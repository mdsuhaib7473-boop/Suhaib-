<?php
if (!function_exists('h')) {
    require_once __DIR__ . '/includes/bootstrap.php';
}
http_response_code(404);
$page_title = 'Page Not Found | ' . get_setting('site_name');
$page_robots = 'noindex,follow';
require __DIR__ . '/templates/header.php';
?>
<section class="section container" style="text-align:center; padding:80px 20px;">
  <h1>404 — Page Not Found</h1>
  <p>The page you're looking for doesn't exist or may have been moved.</p>
  <p><a class="btn btn-primary" href="/">Go to Homepage</a> <a class="btn btn-outline" href="/converters.php">Browse Converters</a></p>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
