(function () {
  function debounce(fn, wait) {
    var t;
    return function () {
      clearTimeout(t);
      var args = arguments, ctx = this;
      t = setTimeout(function () { fn.apply(ctx, args); }, wait);
    };
  }

  function initCalculator(widget) {
    var api = widget.dataset.api;
    var amountEl = widget.querySelector('#calc-amount');
    var fromEl = widget.querySelector('#calc-from');
    var toEl = widget.querySelector('#calc-to');
    var ingredientWrap = widget.querySelector('#calc-ingredient-wrap');
    var ingredientEl = widget.querySelector('#calc-ingredient');
    var swapBtn = widget.querySelector('#calc-swap');
    var resultEl = widget.querySelector('[data-role="result"]');
    var resultUnitEl = widget.querySelector('[data-role="result-unit"]');
    var statusEl = widget.querySelector('[data-role="calc-status"]');

    function unitType(select) {
      var opt = select.options[select.selectedIndex];
      return opt ? opt.parentElement.label : '';
    }

    function toggleIngredientVisibility() {
      var needsIngredient = unitType(fromEl) !== unitType(toEl) && unitType(fromEl) !== 'Temperature' && unitType(toEl) !== 'Temperature';
      ingredientWrap.style.display = needsIngredient ? '' : 'none';
    }

    function runConversion() {
      var amount = parseFloat(amountEl.value);
      if (isNaN(amount)) { return; }
      var params = new URLSearchParams({
        amount: amount,
        from: fromEl.value,
        to: toEl.value,
        ingredient: ingredientEl.value || ''
      });
      statusEl.textContent = 'Calculating…';
      fetch(api + '?' + params.toString())
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (!data.ok) {
            statusEl.textContent = data.error || 'Could not calculate that conversion.';
            return;
          }
          resultEl.textContent = data.result_display;
          resultUnitEl.textContent = data.to.name;
          statusEl.textContent = 'Calculating live as you type — no page reload needed.';
          widget.dispatchEvent(new CustomEvent('gw:converted', { detail: data }));
        })
        .catch(function () {
          statusEl.textContent = 'Network error — please try again.';
        });
    }

    var debouncedRun = debounce(runConversion, 250);

    amountEl.addEventListener('input', debouncedRun);
    fromEl.addEventListener('change', function () { toggleIngredientVisibility(); runConversion(); });
    toEl.addEventListener('change', function () { toggleIngredientVisibility(); runConversion(); });
    ingredientEl.addEventListener('change', runConversion);

    swapBtn.addEventListener('click', function () {
      var f = fromEl.value, t = toEl.value;
      fromEl.value = t;
      toEl.value = f;
      toggleIngredientVisibility();
      runConversion();
    });

    toggleIngredientVisibility();
    runConversion();
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.calculator-widget').forEach(initCalculator);
  });
})();
