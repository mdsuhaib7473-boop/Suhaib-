<?php
require_once __DIR__ . '/includes/bootstrap.php';
$page_title = 'Terms & Conditions | ' . get_setting('site_name');
$breadcrumbs = [['label' => 'Terms & Conditions']];
require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <h1>Terms &amp; Conditions</h1>
  <p><em>Last updated: <?= date('F j, Y') ?></em></p>
  <p>By accessing and using <?= h(get_setting('site_name')) ?>, you agree to the following terms.</p>

  <h2>Use of the Site</h2>
  <p>This site provides free cooking measurement and conversion calculators for general informational and educational purposes. You may use the tools and content for personal, non-commercial purposes.</p>

  <h2>No Professional Advice</h2>
  <p>Conversion results are estimates based on standard unit definitions and typical ingredient densities. They are not a substitute for professional culinary, nutritional or medical advice. See our <a href="/disclaimer.php">Disclaimer</a> for more detail.</p>

  <h2>Intellectual Property</h2>
  <p>Unless otherwise noted, the content, design and code of this site are owned by <?= h(get_setting('site_name')) ?> and may not be copied or republished without permission.</p>

  <h2>Limitation of Liability</h2>
  <p>We make reasonable efforts to keep information accurate but make no warranties about completeness or accuracy. We are not liable for any loss or damage arising from use of this site.</p>

  <h2>Changes to These Terms</h2>
  <p>We may update these terms from time to time. Continued use of the site after changes constitutes acceptance of the updated terms.</p>

  <h2>Contact</h2>
  <p><?= h(get_setting('contact_email')) ?></p>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
