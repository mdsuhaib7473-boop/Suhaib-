<?php
require_once __DIR__ . '/includes/bootstrap.php';

$ingredients = db()->query("SELECT name, slug FROM ingredients WHERE status = 'published' ORDER BY name")->fetchAll();
$articles = db()->query("SELECT title, slug FROM articles WHERE status = 'published' ORDER BY title")->fetchAll();
$convTypes = db()->query("SELECT name, slug FROM conversion_types WHERE is_active = 1 ORDER BY name")->fetchAll();

$page_title = 'Sitemap | ' . get_setting('site_name');
$page_robots = 'index,follow';
$breadcrumbs = [['label' => 'Sitemap']];

require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <h1>Sitemap</h1>

  <h2>Main Pages</h2>
  <ul>
    <li><a href="/">Home</a></li>
    <li><a href="/converters.php">All Converters</a></li>
    <li><a href="/ingredients.php">Ingredients</a></li>
    <li><a href="/articles.php">Guides</a></li>
    <li><a href="/oven-temperatures.php">Oven Temperature Converter</a></li>
    <li><a href="/about.php">About Us</a></li>
    <li><a href="/contact.php">Contact Us</a></li>
  </ul>

  <h2>Converters</h2>
  <ul>
    <?php foreach ($convTypes as $c): ?><li><?= h($c['name']) ?></li><?php endforeach; ?>
  </ul>

  <h2>Ingredients</h2>
  <ul>
    <?php foreach ($ingredients as $i): ?><li><a href="/ingredients/<?= h($i['slug']) ?>/"><?= h($i['name']) ?></a></li><?php endforeach; ?>
  </ul>

  <h2>Guides</h2>
  <ul>
    <?php foreach ($articles as $a): ?><li><a href="/articles/<?= h($a['slug']) ?>/"><?= h($a['title']) ?></a></li><?php endforeach; ?>
  </ul>

  <h2>Legal</h2>
  <ul>
    <li><a href="/privacy.php">Privacy Policy</a></li>
    <li><a href="/terms.php">Terms &amp; Conditions</a></li>
    <li><a href="/disclaimer.php">Disclaimer</a></li>
    <li><a href="/cookie-policy.php">Cookie Policy</a></li>
  </ul>

  <p>An XML sitemap for search engines is available at <a href="/sitemap.xml">/sitemap.xml</a>.</p>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
