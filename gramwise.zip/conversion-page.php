<?php
/**
 * Renders a single programmatic conversion page.
 * Routed from pretty URLs like /grams-to-cups/flour/100-grams-to-cups/
 * via .htaccess to: conversion-page.php?conv=grams-to-cups&ingredient=flour&pslug=100-grams-to-cups
 */
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/templates/calculator.php';
require_once __DIR__ . '/templates/faq-block.php';
require_once __DIR__ . '/templates/related-links.php';

$convSlug = trim((string) ($_GET['conv'] ?? ''));
$ingSlug  = trim((string) ($_GET['ingredient'] ?? ''));
$pageSlug = trim((string) ($_GET['pslug'] ?? ''));

$conversionType = get_conversion_type_by_slug($convSlug);
if (!$conversionType) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$ingredient = null;
if ($ingSlug !== '') {
    $stmt = db()->prepare("SELECT * FROM ingredients WHERE slug = :s AND status = 'published'");
    $stmt->execute(['s' => $ingSlug]);
    $ingredient = $stmt->fetch();
    if (!$ingredient) {
        http_response_code(404);
        require __DIR__ . '/404.php';
        exit;
    }
}

// Look up the stored, admin-generated page (guarantees only intentionally
// generated + published pages are publicly reachable — prevents thin/junk pages).
$sql = "SELECT cp.* FROM conversion_pages cp WHERE cp.conversion_type_id = :ct AND cp.slug = :slug AND cp.status = 'published'";
$params = ['ct' => $conversionType['id'], 'slug' => $pageSlug];
if ($ingredient) {
    $sql .= ' AND cp.ingredient_id = :ing';
    $params['ing'] = $ingredient['id'];
} else {
    $sql .= ' AND cp.ingredient_id IS NULL';
}
$stmt = db()->prepare($sql);
$stmt->execute($params);
$page = $stmt->fetch();

if (!$page) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$valuesStmt = db()->prepare('SELECT * FROM conversion_values WHERE conversion_page_id = :id ORDER BY sort_order');
$valuesStmt->execute(['id' => $page['id']]);
$tableRows = $valuesStmt->fetchAll();

$units = db()->query('SELECT * FROM units WHERE is_active = 1 ORDER BY sort_order')->fetchAll();
$allIngredients = db()->query("SELECT id, name, slug FROM ingredients WHERE status = 'published' ORDER BY name")->fetchAll();

$density = $ingredient ? (float) $ingredient['density_g_per_ml'] : null;
$ingredientLabel = $ingredient ? ' ' . $ingredient['name'] : '';

// Related conversions: same conversion type, different nearby amounts (published only)
$relStmt = db()->prepare(
    "SELECT cp.amount, cp.result, cp.full_url FROM conversion_pages cp
     WHERE cp.conversion_type_id = :ct AND " . ($ingredient ? 'cp.ingredient_id = :ing' : 'cp.ingredient_id IS NULL') . "
       AND cp.status = 'published' AND cp.id != :self
     ORDER BY ABS(cp.amount - :amt) LIMIT 4"
);
$relParams = ['ct' => $conversionType['id'], 'self' => $page['id'], 'amt' => $page['amount']];
if ($ingredient) { $relParams['ing'] = $ingredient['id']; }
$relStmt->execute($relParams);
$related = $relStmt->fetchAll();
$relatedLinks = array_map(function ($r) use ($conversionType, $ingredientLabel) {
    return [
        'label' => format_number((float)$r['amount']) . ' ' . strtolower($conversionType['from_name']) . $ingredientLabel . ' to ' . strtolower($conversionType['to_name']),
        'url' => $r['full_url'],
    ];
}, $related);

// Also link the reverse conversion type + the ingredient's main page
$reverseLinks = [];
if ($ingredient) {
    $reverseLinks[] = ['label' => $ingredient['name'] . ' Measurement Guide', 'url' => '/ingredients/' . $ingredient['slug'] . '/'];
}

$faqStmt = db()->prepare("SELECT question, answer FROM faqs WHERE entity_type = 'conversion_page' AND entity_id = :id AND status = 'published' ORDER BY sort_order");
$faqStmt->execute(['id' => $page['id']]);
$faqs = $faqStmt->fetchAll();
if (!$faqs) {
    $faqs = [
        [
            'question' => 'Is this conversion exact?',
            'answer' => $ingredient
                ? 'This conversion uses ' . $ingredient['name'] . '\'s typical density and is accurate for most home cooking and baking. Minor variation can occur based on brand, moisture and how the ingredient is packed.'
                : 'Yes, this is a direct unit conversion based on standard measurement definitions.',
        ],
        [
            'question' => 'Can I use a kitchen scale instead?',
            'answer' => 'Yes — weighing ingredients on a digital kitchen scale is generally the most accurate method, especially for baking recipes where precision matters.',
        ],
    ];
}

$page_title = $page['seo_title'] ?: ($page['h1'] . ' | ' . get_setting('site_name'));
$page_description = $page['meta_description'];
$breadcrumbs = [
    ['label' => $conversionType['name'], 'url' => '/converters.php?from=' . $conversionType['from_slug'] . '&to=' . $conversionType['to_slug']],
];
if ($ingredient) {
    $breadcrumbs[] = ['label' => $ingredient['name'], 'url' => '/ingredients/' . $ingredient['slug'] . '/'];
}
$breadcrumbs[] = ['label' => $page['h1']];

require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <h1><?= h($page['h1']) ?></h1>
  <?php if ($page['intro_text']): ?><p><?= nl2br(h($page['intro_text'])) ?></p><?php endif; ?>

  <div class="result-box">
    <div class="big"><?= format_number((float)$page['amount']) ?> <?= h($conversionType['from_abbr']) ?><?= $ingredientLabel ? ' ' . h($ingredient['name']) : '' ?> = <?= format_number((float)$page['result'], 3) ?> <?= h($conversionType['to_abbr']) ?></div>
  </div>

  <?php render_calculator($units, $allIngredients, [
      'amount' => $page['amount'],
      'from' => $conversionType['from_slug'],
      'to' => $conversionType['to_slug'],
      'ingredient' => $ingredient['slug'] ?? ($allIngredients[0]['slug'] ?? ''),
  ]); ?>

  <h2>Conversion Formula</h2>
  <div class="formula-box">
    <?= h($conversionType['from_name']) ?> → <?= h($conversionType['to_name']) ?><?= $ingredient ? ' (using ' . h($ingredient['name']) . '\'s density of ' . h((string)$ingredient['density_g_per_ml']) . ' g/ml)' : '' ?>
  </div>

  <?php if ($tableRows): ?>
  <h2><?= h($conversionType['from_name']) ?><?= $ingredientLabel ? h($ingredientLabel) : '' ?> to <?= h($conversionType['to_name']) ?> Conversion Table</h2>
  <table class="conv-table">
    <thead><tr><th><?= h($conversionType['from_name']) ?></th><th><?= h($conversionType['to_name']) ?></th></tr></thead>
    <tbody>
      <?php foreach ($tableRows as $row): ?>
        <tr><td><?= format_number((float)$row['amount']) ?> <?= h($conversionType['from_abbr']) ?></td><td><?= format_number((float)$row['result'], 3) ?> <?= h($conversionType['to_abbr']) ?></td></tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>

  <?php if ($ingredient): ?>
    <h2>About <?= h($ingredient['name']) ?></h2>
    <p><?= h($ingredient['short_description']) ?> <a href="/ingredients/<?= h($ingredient['slug']) ?>/">View the full <?= h($ingredient['name']) ?> measurement guide →</a></p>
  <?php endif; ?>

  <?php if ($page['tips_text']): ?>
    <h2>Helpful Tips</h2>
    <p><?= nl2br(h($page['tips_text'])) ?></p>
  <?php endif; ?>

  <?php render_related_links('Related Conversions', array_merge($relatedLinks, $reverseLinks)); ?>

  <?php render_faq_block($faqs); ?>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
