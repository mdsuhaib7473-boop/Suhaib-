<?php
/**
 * ONE-TIME SETUP SCRIPT — creates the first super_admin account.
 *
 * Usage:
 *   1. Upload this file to your site root alongside the rest of the app.
 *   2. Visit https://yoursite.com/install-create-admin.php in your browser
 *      (after importing database.sql and configuring config/config.php).
 *   3. Fill in the form to create your admin account.
 *   4. DELETE THIS FILE from the server immediately afterward — leaving it
 *      live would let anyone create an admin account.
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/auth.php';
start_secure_session();

// Safety switch: refuses to run if an admin account already exists.
$existingAdmins = (int) db()->query('SELECT COUNT(*) FROM users')->fetchColumn();

$done = false;
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if ($existingAdmins > 0) {
        $errors[] = 'An admin account already exists. Delete this file — use the Admin Users screen inside /admin to add more accounts.';
    } else {
        $username = trim((string) $_POST['username']);
        $email = trim((string) $_POST['email']);
        $password = (string) $_POST['password'];
        $confirm = (string) $_POST['password_confirm'];

        if (!preg_match('/^[a-zA-Z0-9_\.\-]{3,60}$/', $username)) $errors[] = 'Username must be 3-60 characters (letters, numbers, . _ -).';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email is required.';
        if (strlen($password) < 10) $errors[] = 'Password must be at least 10 characters.';
        if ($password !== $confirm) $errors[] = 'Passwords do not match.';

        if (!$errors) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = db()->prepare(
                "INSERT INTO users (role_id, username, email, password_hash, full_name) VALUES (1, :u, :e, :p, 'Site Administrator')"
            );
            $stmt->execute(['u' => $username, 'e' => $email, 'p' => $hash]);
            $done = true;
        }
    }
}
?><!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Create Admin Account</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex,nofollow">
<style>
body{font-family:sans-serif;max-width:480px;margin:60px auto;padding:0 20px;color:#2A241E;}
input{width:100%;padding:10px;margin:6px 0 14px;border:1px solid #ccc;border-radius:6px;box-sizing:border-box;}
button{background:#C97A3D;color:#fff;border:none;padding:12px 20px;border-radius:6px;cursor:pointer;font-size:1rem;}
.alert{background:#FBEAE5;color:#B3432E;padding:12px;border-radius:6px;margin-bottom:14px;}
.success{background:#E6F0EA;color:#2E4C42;padding:16px;border-radius:6px;}
</style></head>
<body>
<h1>Create Admin Account</h1>
<?php if ($done): ?>
  <div class="success"><strong>Admin account created.</strong> You can now log in at <a href="/admin/login.php">/admin/login.php</a>.<br><br><strong>Important:</strong> delete this file (<code>install-create-admin.php</code>) from your server now.</div>
<?php else: ?>
  <?php if ($existingAdmins > 0): ?>
    <div class="alert">An admin account already exists. For security, please delete this file. To add more admins, log into <a href="/admin/login.php">/admin</a> and use the Admin Users screen.</div>
  <?php else: ?>
    <?php foreach ($errors as $e): ?><div class="alert"><?= h($e) ?></div><?php endforeach; ?>
    <form method="post">
      <?= csrf_field() ?>
      <label>Username</label><input type="text" name="username" required>
      <label>Email</label><input type="email" name="email" required>
      <label>Password (min. 10 characters)</label><input type="password" name="password" required minlength="10">
      <label>Confirm Password</label><input type="password" name="password_confirm" required minlength="10">
      <button type="submit">Create Admin Account</button>
    </form>
  <?php endif; ?>
<?php endif; ?>
</body>
</html>
