<?php
/**
 * GramWise - Main configuration file
 * Copy this file's values in during installation (see INSTALL.md).
 * Do NOT commit real credentials to version control.
 */

// ---------------------------------------------------------------
// Database credentials — set these during installation
// ---------------------------------------------------------------
define('DB_HOST', 'localhost');
define('DB_NAME', 'gramwise_db');
define('DB_USER', 'gramwise_user');
define('DB_PASS', 'CHANGE_ME');
define('DB_CHARSET', 'utf8mb4');

// ---------------------------------------------------------------
// Site
// ---------------------------------------------------------------
define('SITE_URL', 'https://example.com');       // no trailing slash
define('SITE_NAME', 'GramWise');
define('ADMIN_EMAIL', 'admin@example.com');

// ---------------------------------------------------------------
// Security
// ---------------------------------------------------------------
// Generate a long random string for production, e.g. via bin2hex(random_bytes(32))
define('APP_SECRET', 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET_STRING');
define('SESSION_NAME', 'gramwise_session');
define('LOGIN_MAX_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_MINUTES', 15);

// ---------------------------------------------------------------
// Uploads
// ---------------------------------------------------------------
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_URL', SITE_URL . '/uploads/');
define('MAX_UPLOAD_BYTES', 5 * 1024 * 1024); // 5MB
define('ALLOWED_UPLOAD_MIME', ['image/jpeg', 'image/png', 'image/webp', 'image/gif']);

// ---------------------------------------------------------------
// Environment
// ---------------------------------------------------------------
define('APP_ENV', 'production'); // 'production' or 'development'

if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
}

date_default_timezone_set('UTC');
