<?php
require_once __DIR__ . '/includes/bootstrap.php';
$page_title = 'Disclaimer | ' . get_setting('site_name');
$breadcrumbs = [['label' => 'Disclaimer']];
require __DIR__ . '/templates/header.php';
?>
<section class="section container">
  <h1>Disclaimer</h1>
  <p>The conversion calculators, tables and articles on <?= h(get_setting('site_name')) ?> are provided for general cooking and baking guidance only.</p>
  <h2>Accuracy of Conversions</h2>
  <p>Ingredient conversions rely on typical density values, which can vary by brand, freshness, moisture content, altitude and how an ingredient is measured or packed. Results should be treated as close estimates rather than laboratory-precise figures. For recipe development or professional baking where precision is critical, always weigh ingredients directly on a calibrated kitchen scale.</p>
  <h2>Not Medical or Nutritional Advice</h2>
  <p>Nothing on this site constitutes dietary, nutritional or medical advice. Consult a qualified professional for advice specific to your health needs.</p>
  <h2>External Links</h2>
  <p>Any links to third-party sites are provided for convenience. We are not responsible for their content or accuracy.</p>
</section>
<?php require __DIR__ . '/templates/footer.php'; ?>
